<?php
$conn = mysqli_connect("localhost","root","","df");
if($conn){
    echo "db connected <br>";
}
else{
    echo "db not connected <br>";
}

?>