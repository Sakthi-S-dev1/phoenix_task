<?php
require "config.php";
if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $h_pass = password_hash($pass, PASSWORD_DEFAULT);
    
    $prefix = "HAM";
    $len = strlen(($prefix));

    echo var_dump($len)."<br>";

    $date = date('d');
    $year = date('y');

    $sql = "SELECT user_id FROM users ORDER BY id DESC LIMIT 1";
    $result = mysqli_query($conn, $sql);
    if ($row = mysqli_fetch_assoc($result)) {
        
        
        if($len){
            /*  $last_user_id = $row['user_id'];
                $num = (int)substr($last_user_id, 9);
                $num = $num + 1;
                echo $num."<br>";
                echo var_dump($num)."<br>";

                $new_user_id = $prefix."-".$date."-".$year."-".str_pad($num, 3, 0, STR_PAD_LEFT);
                echo $new_user_id ."<br>";
        }
        else if($len == 3){ */
                $last_user_id = $row['user_id'];
                $arr = explode("-",$last_user_id);
                $num = end($arr); // "001"
                $num = (int)$num; //1
                $num = $num + 1;
                $new_user_id = $prefix."-".$date."-".$year."-".str_pad($num, 3, 0, STR_PAD_LEFT);
                echo $new_user_id ."<br>";
        }
        else{
            echo "please enter the string code <br>";
        }
    } 
    else {
        $new_user_id = $prefix."-".$date."-".$year."-"."001";
        echo $new_user_id;
        }
    
    if ($new_user_id) {
        $query = "INSERT INTO users(name,user_id,email,password) VALUES('$name','$new_user_id','$email','$h_pass') ";
        $values = mysqli_query($conn, $query);
        if ($values) {
            echo "data inserted successfully";
        } else {
            echo "data not inserted";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>

<body>
    <form action="" method="post">
        <div class="input">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
        </div>
        <button type="submit">submit</button>
    </form>
</body>

</html>