<?php
require "db.php";

// Set headers to force download as Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=My_dashboard_data.xls");

$output = "";
$output .= "ID\tName\tEmail\tPhone\tRole\n";

// Fetch data
$sql = "SELECT id, Name, Email, Phone, Role FROM admin";
$result = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    $output .= $row['id'] . "\t" . $row['Name'] . "\t" . $row['Email'] . "\t" . $row['Phone'] . "\t" . $row['Role'] . "\n";
}

echo $output;
exit; 
?>
