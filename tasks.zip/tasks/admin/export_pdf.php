<?php
require('fpdf/fpdf.php');
require('db.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->Image('logo.jpg',0,0,50);

$pdf->SetFont("Arial","B",18);
$pdf->Cell(60);
$pdf->Ln(5);

$pdf->SetFont("Arial","B",18);
$pdf->Cell(60);
$pdf->Cell(70, 10, "My Admin User Panel",1,1,"C");

$pdf->SetFont("Arial","",15);
$pdf->Cell(45);
$pdf->Cell(100, 10, "Colected datas from MySql Database",1,0,"C");

$pdf->SetLineWidth(0.5);
$pdf->Line(5,45,205,45);// x1, y1, x2, y2

$pdf->Ln(25);

$pdf->SetFont("Arial","B",15);
$pdf->Cell(10,10,'Id',1,0,'C');
$pdf->Cell(50,10,'Name',1,0,'C');
$pdf->Cell(70,10,'Email',1,0,'C');
$pdf->Cell(60,10,'Phone',1,0,'C');

$pdf->Ln();

//for data
$sql = "SELECT * FROM admin";
$result = mysqli_query($conn, $sql);

$pdf->SetFont('Arial', '', 12);
while($row = mysqli_fetch_assoc($result)){
    $pdf->Cell(10, 10, $row['id'],1);
    $pdf->Cell(50,10,$row['Name'],1);
    $pdf->Cell(70,10,$row['Email'],1);
    $pdf->Cell(60,10,$row['Phone'],1);
    $pdf->Ln();
}

$pdf->Output("D", "new_pdf.pdf");

?>

