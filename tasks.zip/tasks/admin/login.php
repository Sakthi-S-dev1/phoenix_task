<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log-In</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container-fluid w-50 my-5 border p-5">
        <h2>Log-In Form</h2>
        <form action="" class="form" id="l-form">
            <div class="form-group">
                <label for="" class="form-label">Email or Phone</label>
                <input type="text" name="erp" id="erp" class="form-control"><!--erp = email or phone-->
                <span class="invalid-feedback" id ="erpError"></span>
            </div>
            <div class="form-group">
                <label for="" class="form-label">Password</label>
                <input type="text" name="pass" id="pass" class="form-control">
                <span class="invalid-feedback" id="passwordError"></span>
            </div>
            <div class="button text-end mt-5">
                <button class="btn btn-secondary" id="back">Back</button>
                <button type="submit" class="btn btn-success ms-2" id="login">Log-In</button>
            </div>
        </form>
    </div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $("#back").click(function(e){
        e.preventDefault();
        window.location.href = "register.php";
    });

    $("#login").click(function(e){
        e.preventDefault();

        let erp = $("#erp").val().trim();
        let pass = $("#pass").val().trim();

        if(erp =='' || pass == ''){
            alert("both fields are required");
            return;
        }

        let formData = new FormData($("#l-form")[0]);

        $.ajax({
            url: "login_check.php",
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function(data){
                data = data.trim();
                if(data == "admin"){
                    window.location.href = "dashboard.php";
                } else if(data == "user"){
                    window.location.href = "user.php";
                } else {
                    alert(data);
                }
                $("#l-form")[0].reset();
            }
        });
    });
</script>
  
</body>
</html>