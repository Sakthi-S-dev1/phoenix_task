<?php
require "db.php";

$erp =$_POST['erp'];
$pass =$_POST['pass'];

$sql = "SELECT * FROM admin WHERE (Email='$erp' OR Phone='$erp')";
$result = mysqli_query($conn,$sql);

if($result){

   if(mysqli_num_rows($result) > 0){
      $row = mysqli_fetch_assoc($result);
      if(password_verify($pass,$row['Password'])){
         echo $row['Role'];
         exit;
      }
      echo "incorrect pass";
      exit;
   }
   echo "user not found";
   exit;
}
echo "query failed";
exit;
/* $sql="SELECT * FROM admin WHERE (Email='$erp' OR Phone='$erp') AND Password='$pass'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result) > 0){
   $row = mysqli_fetch_assoc($result);
   echo $row['Role'];
   exit();

} */
//echo "error";
?>