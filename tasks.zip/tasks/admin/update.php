<?php
require "db.php";
$id = $_GET['id'];


$sql = "SELECT * FROM admin WHERE id=$id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);


function check($d) {
    return htmlspecialchars(trim($d));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $new_name = check($_POST['n_name']);
    $new_email = check($_POST['n_email']);
    $new_phone = check($_POST['n_phone']);

    if (empty($new_name) || empty($new_email) || empty($new_phone)) {
        echo "All fields are required";
    } else {
        $sql = "UPDATE admin SET Name='$new_name', Email='$new_email', Phone='$new_phone' WHERE id=$id";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            header("location: dashboard.php");
            exit();
        } else {
            echo "error updating record.";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container-fluid w-75 my-5">
        <h2>Update here</h2>
        <form action="" id="form" class="form" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="" class="form-label">Name</label>
                <input type="text" name="n_name" class="form-control" id="name" value="<?php echo $row['Name'] ?>">
                <span class="invalid-feedback" id=""></span>
            </div>
            <div class="form-group">
                <label for="" class="form-label">Email</label>
                <input type="email" name="n_email" class="form-control" id="email" value="<?php echo $row['Email'] ?>">
                <span class="invalid-feedback"></span>
            </div>
            <div class="form-group">
                <label for="" class="form-label">Phone</label>
                <input type="text" name="n_phone" class="form-control" id="phone" value="<?php echo $row['Phone'] ?>">
                <span class="invalid-feedback"></span>
            </div>
            
            <div class="invalid-feedback" id="error"></div>
            <div class="button mt-3">
                <button class="btn btn-primary" id="update">Update</button>
            </div>
        </form>
    </div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function(){
        
        function validName(){
        let inputName = $("#name").val().trim();
        let namePattern = /^[a-zA-Z\s]+$/;

        $("#name").removeClass("is-invalid");
        $("#nameError").text("");

        if(inputName === ''){
            $("#nameError").text("name is required");
            $("#name").addClass("is-invalid");
            return false;
        } else if(!namePattern.test(inputName)){
            $("#nameError").text("name only contain letters and spaces");
            $("#name").addClass("is-invalid");
            return false;
        }
         return true;
    };

    function validEmail(){
        let inputEmail = $("#email").val().trim();
        let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        $("#email").removeClass("is-invalid");
        $("#emailError").text("");

        if(inputEmail === ''){
            $("#emailError").text("your email is required.");
            $("#email").addClass("is-invalid");
            return false;
        }else if(!emailPattern.test(inputEmail)){
            $("#emailError").text("please enter the valid email.");
            $("#email").addClass("is-invalid");
            return false;
        }
         return true;
    }

    function validPhone(){
        let inputPhone = $("#phone").val().trim();

        $("#phone").removeClass("is-invalid");
        $("#phoneError").text("");

        if(inputPhone === ''){
            $("#phoneError").text("phone number is required.");
            $("#phone").addClass("is-invalid");
            return false;
        }
        else if(!/^\d{10}$/.test(inputPhone)){  
            $("#phoneError").text("length should be 10.");
            $("#phone").addClass("is-invalid");
            return false;
        }
         return true;
    }

    $("#name").on("input", validName);
    $("#email").on("input", validEmail);
    $("#phone").on("input", validPhone);

    $("#update").click(function(e){
        

        let inputName = validName();
        let inputEmail = validEmail();
        let inputPhone = validPhone();

        if (!inputName || !inputEmail || !inputPhone) {
            e.preventDefault();
            alert("errors in the form.");
            return;
        }
        $("#form").submit();
    })
    })
</script>
</body>
</html>