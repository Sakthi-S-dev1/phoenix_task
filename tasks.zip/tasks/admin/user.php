<?php
echo "this is user home.php";
?>