<?php
require "config.php";
 if($_SERVER["REQUEST_METHOD"]=="POST"){
    $name = $age = $email = '';
    $name_err = $age_err = $email_err = '';
    //name validation
    $name = trim($_POST['name']);
    if(empty($name)){
        $name_err = "your name is required";
    }
    elseif(!preg_match("/^[a-zA-Z ]+$/", $name)){
        /* The preg_match() function searches a string for pattern, 
        returning true if the pattern exists, and false otherwise.*/
        $name_err = "only letters and spaces are allowed";
    }

    // age validation
    $age = trim($_POST['age']);
    if(empty($age)){
        $age_err = "your age is required";
    }
    elseif(intval($age) < 18){
        $age_err = "you have to wait ".(18-$age)."yrs to vote";
    }

    //email validation
    $email = trim($_POST['email']);
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $email_err = "please enter your valid email";
    }
    else{
        $sql = "SELECT id FROM students WHERE email = '$email'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0){
            $email_err = "this email is already existing";
        }
    }

    if(empty($name_err) && empty($age_err) && empty($email_err)){
            //if file uploaded
        if(isset($_FILES['pic']) && $_FILES['pic']['error']==0){
            $filename = $_FILES['pic']['name'];
            $tmp = $_FILES['pic']['tmp_name'];//tmp location
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            $new_pic_name = "img_".time().".".$ext;
            $folder = "assets/".$new_pic_name;

            move_uploaded_file($tmp,$folder);
        }
    

        $sql = "INSERT INTO students (name,age,email,profile) VALUE ('$name', '$age', '$email', '$new_pic_name')";
        $result = mysqli_query($conn, $sql);
        if($result){
            header("location: index.php");   
            exit();//stops php from here
        }
        else{
            echo "error";
        }
    }
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>create </title>
</head>
<body>
    <form action="" method="post" enctype="multipart/form-data">
        
        <input type="text" name="name" placeholder="name">
        <span><?php echo $name_err ?></span>
        <br><br>

        <input type="number" name="age" placeholder="age">
        <span><?php echo $age_err ?></span>
        <br><br>
        
        <input type="email" name="email" id="" placeholder="email">
        <span><?php echo $email_err ?></span>
        <br><br>
        
        your Passpord Photo <br>
        <input type="file" name="pic">
        <br><br>
        
        <input type="submit" value="Submit" >
    </form>
</body>
</html>
