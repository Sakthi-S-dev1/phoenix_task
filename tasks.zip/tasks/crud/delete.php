<?php
    require "config.php";
    echo "id = ".$_GET['id']." is <br>";
    $id = intval($_GET['id']);
    if(isset($id) && !empty($id)){
        $sql = "DELETE FROM students WHERE id = $id";
        $result = mysqli_query($conn, $sql);
        if($result){
            echo "deleted successfully";
            header("location: index.php");
            exit();
        }
        else{
        echo "delete failed";
        }
    }
    else{
        echo "error";
    }
?>