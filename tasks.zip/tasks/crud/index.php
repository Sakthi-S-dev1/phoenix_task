<?php
    require "config.php";
    $sql = "SELECT * FROM students";
    $result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>student details</title>
    <style>
        table{
            border:1px solid black;
            width:50%;
        }
        td,th{
            text-align:center;
            border:1px solid black;
        }
    </style>
</head>
<body>
    <h2>students details  <span>    <a href="create.php">new</a> </span>  </h2>
    <table>
        <thead>
            <th>id</th>   
            <th>Profile</th> 
            <th>name</th>    
            <th>age</th>    
            <th>email</th>    
            <th>actions</th>    
        </thead>
        <tbody>
        <?php
        if(mysqli_num_rows($result) >0){
            while($row = mysqli_fetch_assoc($result)){
                ?>
            <tr>
                <?php
                echo "<td>".$row['id']."</td>";
                echo "<td>".$row['profile']."</td>";
                echo "<td>".$row['name']."</td>";
                echo "<td>".$row['age']."</td>";
                echo "<td>".$row['email']."</td>";
                echo "<td>";
                    echo "<a href='update.php?id=".$row['id']."' >Update</a>"." / ";
                    
                    echo "<a href='delete.php?id=".$row['id']."' onclick=\"return confirm('are you sure')\" >Delete</a>";// use \ for spl chars use
                echo "</td>";
                ?>
            <tr>
                <?php
            }
        }
        ?>
        
            
        </tbody>
    </table>

</body>
</html>