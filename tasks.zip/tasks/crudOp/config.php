<?php
    $host = "localhost";
    $username = "root";
    $pwd = "";
    $db = "user_system";
    
    $conn = new mysqli($host, $username, $pwd, $db);
    if($conn->connect_error){
        die("could not connect".$conn->connect_error);
    } 

?>