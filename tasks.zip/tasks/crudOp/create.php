<?php
require "config.php";
$fname = $uname = $email = $pass = '';
$fname_err = $uname_err = $email_err = $pass_err = "";
//processing the form data when form is submitted
if ($_SERVER["REQUEST_METHOD"]=="POST"){
    //name validation
    $input_name = trim($_POST['name']);
    if(empty($input_name)){
        $fname_err = "please enter the name";
    }
    elseif(!filter_var($input_name,FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $fname_err = "please enter the valid name";
    }
    else{
        $fname = $input_name;
    }

    //username validation
    $input_uname = trim($_POST['username']);
    if(empty($input_uname)){
        $uname_err = "please enter the username";
    }
    elseif(!filter_var($input_uname,FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z_\s]+$/")))){
        $uname_err = "please enter the valid username";
    }
    else{
        $uname = $input_uname;
    }

    //email validation
    $input_email = trim($_POST['email']);
    if(empty($input_email)){
        $email_err = "please enter the email";
    }
    elseif(!filter_var($input_email,FILTER_VALIDATE_EMAIL)){
        $email_err = "please enter the valid email";
    }
    else {
        $email = $input_email;

        // check email already exists
        $check_sql = "SELECT id FROM users WHERE email = ?";
        if ($check_stmt = mysqli_prepare($conn, $check_sql)) {
            mysqli_stmt_bind_param($check_stmt, "s", $email);
            mysqli_stmt_execute($check_stmt);
            mysqli_stmt_store_result($check_stmt);
            if (mysqli_stmt_num_rows($check_stmt) > 0) {
                $email_err = "This email is already taken.";
            }
            mysqli_stmt_close($check_stmt);
        }
    }


    //password validation
    $input_pwd = trim($_POST['password']);
    if(empty($input_pwd)){
        $pass_err = "password is required";
    }
    elseif(strlen($input_pwd) < 6 ){
        $pass_err = "password must be atleast 6 characters";
    }
    else{
        $pass = password_hash($input_pwd,PASSWORD_DEFAULT);
    }


//checking input errors before send it to the db
if(empty($fname_err) && empty($uname_err) && empty($email_err) && empty($pass_err)){
        // Check if username already exists
        $check_sql = "SELECT id FROM users WHERE username = ?";
            if ($check_stmt = mysqli_prepare($conn, $check_sql)) {
                mysqli_stmt_bind_param($check_stmt, "s", $uname);
                mysqli_stmt_execute($check_stmt);
                mysqli_stmt_store_result($check_stmt);

                if (mysqli_stmt_num_rows($check_stmt) > 0) {
                    $uname_err = "Username already exists. Please choose another.";
                    }
        }
    }
if(empty($fname_err) && empty($uname_err) && empty($email_err) && empty($pass_err)){

    // profile image handling
    $profile_img = "";

    if (isset($_FILES["profile_img"]) && $_FILES["profile_img"]["error"] == 0) {
        $target_dir = "uploads/";
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $extension = strtolower(pathinfo($_FILES["profile_img"]["name"], PATHINFO_EXTENSION));

        if (!in_array($extension, $allowed)) {
            echo "only JPG, JPEG, PNG, and GIF files are allowed.";
        }
        else {
            $profile_img = "img_" . time() . "." . $extension;
            $target_file = $target_dir . $profile_img;

        if (!move_uploaded_file($_FILES["profile_img"]["tmp_name"], $target_file)) {
            echo "error uploading file.";
        }
    }
    }

        //prepare an insert statement
        $sql = "INSERT INTO users(full_name, username, email, password, profile_img) VALUES(?,?,?,?,?) ";
        $stmt = mysqli_prepare($conn,$sql);
        if($stmt){
            //bind variables to the prepare statement and set parameters
            mysqli_stmt_bind_param($stmt, "sssss", $fname, $uname, $email, $pass, $profile_img);
            //attepmt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                //records created successfully , now redirect to the landing page
                header("location: index.php");
                exit();
            }
            else{
                echo "somthing went wrong, please try later";
            } 
        }
        //close prepare stmt
        mysqli_stmt_close($stmt);

    }
    //close the connection
    mysqli_close($conn);

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>create form</title>
    <style>
        .wrapper{
            width:600px;
            margin:0 auto;
        }

    </style>
</head>
<body>
    <div class="wrapper mb-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">create new record</h2>
                    <p>fill this form to create the new user</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="">Profile pic</label>
                            <input type="file" name="profile_img" value="" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Full Name</label>
                            <input type="text" name ="name" class="form-control <?php echo (!empty($fname_err))? 'is-invalid': ''; ?>" value="<?php echo $fname ?>">
                            <span class="invalid-feedback"><?php echo $fname_err; ?></span>
                        </div>
                        <div class="form-group">
                            <label for="" >Username</label>
                            <input type="text" name="username" class="form-control <?php echo (!empty($uname_err)) ? 'is-invalid': ''; ?> " value="<?php echo $uname ?>">
                            <span class="invalid-feedback"><?php echo $uname_err; ?></span>
                        </div>
                        <div class="form-group">
                            <label for="">E-mail</label>
                            <input type="text" name="email" class="form-control <?php echo (!empty($email_err))? 'is-invalid': ''; ?>" value = "<?php echo $email ?>">
                            <span class="invalid-feedback"><?php echo $email_err; ?></span>
                        </div>
                        <div class="form-group">
                            <label for="">Password</label>
                            <input type="text" name="password" class="form-control <?php echo (!empty($pass_err))? 'is-invalid': ''; ?>" value = "<?php echo $pass ?>">
                            <span class="invalid-feedback"><?php echo $pass_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Proceed">
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>