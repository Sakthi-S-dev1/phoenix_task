<?php
// delete after confirmation
if (isset($_POST['id']) && !empty(trim($_POST['id']))) {
    require "config.php";
    $sql = "DELETE FROM users WHERE id = ?";

    if ($stmt = mysqli_prepare($conn, $sql)) {
        $param_id = trim($_POST['id']);
        mysqli_stmt_bind_param($stmt, "i", $param_id);

        if (mysqli_stmt_execute($stmt)) {
            header("location: index.php");
            exit();
        } else {
            echo "Something went wrong. Please try again later.";
        }
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
} else {
    // If no ID in URL, redirect
    if (empty(trim($_GET["id"]))) {
        header("location: index.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper {
            width: 800px;
            margin: 0 auto;
        }
        img {
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2 class="mt-5 mb-3">Delete Record</h2>
        <?php
        // Show the one record
        require "config.php";
        $id = trim($_GET["id"]);
        $sql = "SELECT * FROM users WHERE id = ?";

        if ($stmt = mysqli_prepare($conn, $sql)) {

            mysqli_stmt_bind_param($stmt, "i", $id);
            if (mysqli_stmt_execute($stmt)) 
                {
                $result = mysqli_stmt_get_result($stmt);
                if (mysqli_num_rows($result) == 1) {
                    $row = mysqli_fetch_assoc($result);
                    echo "<table class='table table-bordered'>";
                    echo "<thead><tr>
                            <th>#ID</th>
                            <th>Profile Pic</th>
                            <th>Pic Name</th>
                            <th>Full Name</th>
                            <th>Username</th>
                            <th>Email</th>
                        </tr></thead>";
                    echo "<tbody><tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td><img src='uploads/" . $row['profile_img'] . "' width='75' height='75' class='rounded'></td>";
                    echo "<td>" . $row['profile_img'] . "</td>";
                    echo "<td>" . $row['full_name'] . "</td>";
                    echo "<td>" . $row['username'] . "</td>";
                    echo "<td>" . $row['email'] . "</td>";
                    echo "</tr></tbody></table>";
                } 
                else {
                    echo "<div class='alert alert-danger'>No record found with this ID.</div>";
                }
            }
        }
        ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="alert alert-danger">
                <input type="hidden" name="id" value="<?php echo trim($_GET["id"]); ?>">
                <p>are you sure want to delete this record?</p>
                <input type="submit" value="Yes" class="btn btn-danger">
                <a href="index.php" class="btn btn-secondary">No</a>
            </div>
        </form>
    </div>
</body>
</html>
