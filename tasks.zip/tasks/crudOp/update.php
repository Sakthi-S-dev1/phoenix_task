<?php
require "config.php";
$fname = $uname = $email = $pass = "";
$fname_err = $uname_err = $email_err = $pass_err = "";
$profile = "";

if (isset($_POST['id']) && !empty($_POST['id'])) {
    $id = $_POST['id'];

    // name validation
    $input_name = trim($_POST['name']);
    if (empty($input_name)) {
        $fname_err = "please enter the name";
    } elseif (!filter_var($input_name, FILTER_VALIDATE_REGEXP, ["options" => ["regexp" => "/^[a-zA-Z\s]+$/"]])) {
        $fname_err = "please enter the valid name";
    } else {
        $fname = $input_name;
    }

    // username validation
    $input_uname = trim($_POST['username']);
    if (empty($input_uname)) {
        $uname_err = "please enter the username";
    } elseif (!filter_var($input_uname, FILTER_VALIDATE_REGEXP, ["options" => ["regexp" => "/^[a-zA-Z_\s]+$/"]])) {
        $uname_err = "please enter the valid username";
    } else {
        $uname = $input_uname;
    }

    // email validation
    $input_email = trim($_POST['email']);
    if (empty($input_email)) {
        $email_err = "please enter the email";
    } 
    elseif (!filter_var($input_email, FILTER_VALIDATE_EMAIL)) {
        $email_err = "please enter the valid email";
    }
    else {
        $email = $input_email;
    }


    // password validation
    $input_pwd = trim($_POST['password']);
    if (empty($input_pwd)) {
        $pass_err = "password is required";
    } elseif (strlen($input_pwd) < 6) {
        $pass_err = "password must be at least 6 characters";
    } else {
        $pass = password_hash($input_pwd, PASSWORD_DEFAULT);
    }

    $old_img = $_POST['current_img'] ?? "";
    $profile_img = $old_img;
    $target_dir = "uploads/";

    if (empty($fname_err) && empty($uname_err) && empty($email_err)) {
        //if new file uploaded
        if (isset($_FILES['profile_img']) && $_FILES['profile_img']['error'] === 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            $extension = strtolower(pathinfo($_FILES["profile_img"]["name"], PATHINFO_EXTENSION));

            if (in_array($extension, $allowed)) {
                $new_img = "img_" . time() . "." . $extension;
                $target_file = $target_dir . $new_img;

                if (move_uploaded_file($_FILES["profile_img"]["tmp_name"], $target_file)) {
                    if ($old_img && file_exists("uploads/$old_img")) {
                        unlink("uploads/$old_img");
                    }
                    $profile_img = $new_img;
                }
            }
        }

        $sql = "UPDATE users SET full_name=?, username=?, email=?, password=?, profile_img=? WHERE id=?";
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "sssssi", $fname, $uname, $email, $pass, $profile_img, $id);
            if (mysqli_stmt_execute($stmt)) {
                header("location: index.php");
                exit();
            } else {
                echo "Something went wrong, try again later.";
            }
        }
        mysqli_stmt_close($stmt);
    }
    mysqli_close($conn);
} 
elseif (isset($_GET['id']) && !empty(trim($_GET['id']))) {

    $id = trim($_GET['id']);
    $sql = "SELECT * FROM users WHERE id=?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $id);
        if (mysqli_stmt_execute($stmt)) {
            $result = mysqli_stmt_get_result($stmt);
            if (mysqli_num_rows($result) == 1) {
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                $fname = $row['full_name'];
                $uname = $row['username'];
                $email = $row['email'];
                $pass = $row['password'];
                $profile = $row['profile_img'];
            } else {
                header("location: error.php");
                exit();
            }
        } else {
            echo "Something went wrong, try again later.";
        }
        mysqli_stmt_close($stmt);
    }
    mysqli_close($conn);
} else {
    header("location: error.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper {
            width: 600px;
            margin: 0 auto;
        }
        .img {
            width: 200px;
            height: 200px;
            border: 5px solid whitesmoke;
            object-fit: cover;
        }
        .img:hover {
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            transition: box-shadow 0.5s ease;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <div class="container-fluid">
        <h2 class="mt-5">update records</h2>
        <p>edit the input values and submit to update the users data</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
            <?php if (!empty($profile)): ?>
                <div class="form-group" id="profile-box">
                    <img src="uploads/<?php echo $profile; ?>" class="img rounded-circle mb-2">
                    <br>
                    <button type="button" class="btn btn-danger btn-sm" id="remove-img-btn">Remove Profile</button>
                </div>
            <?php endif; ?>

            <div class="form-group">
                <input type="hidden" name="current_img" id="current_img" value="<?php echo $profile; ?>">
                <label>New Profile</label>
                <input type="file" name="profile_img" class="form-control">
            </div>

            <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" class="form-control <?php echo (!empty($fname_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $fname ?>">
                <span class="invalid-feedback"><?php echo $fname_err; ?></span>
            </div>

            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($uname_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $uname ?>">
                <span class="invalid-feedback"><?php echo $uname_err; ?></span>
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="text" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email ?>">
                <span class="invalid-feedback"><?php echo $email_err; ?></span>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="text" name="password" class="form-control <?php echo (!empty($pass_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $pass ?>" placeholder="New Password">
                <span class="invalid-feedback"><?php echo $pass_err; ?></span>
            </div>

            <input type="hidden" name="id" value="<?php echo $id ?>">
            <input type="submit" class="btn btn-primary" value="Done">
            <a href="index.php" class="btn btn-secondary ml-2">Cancel</a>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$('#remove-img-btn').on('click', function () {
    if (confirm("Are you sure you want to delete this profile picture?")) {
        $.ajax({
            url: 'delete_pic.php',
            type: 'POST',
            data: { id: <?php echo json_encode($id); ?> },
            success: function (response) {
                if (response.trim() === 'success') {
                    $('#profile-box').remove();
                    $('#current_img').val('');
                } else {
                    alert('Failed to delete image.');
                }
            },
            error: function () {
                alert('AJAX request failed.');
            }
        });
    }
});
</script>
</body>
</html>
