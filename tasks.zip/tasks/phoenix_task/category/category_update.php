<?php
require "../auth_session.php";
$user_name = $_SESSION['user_name'];
$role = $_SESSION['role'];
require "../db.php";
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM category WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $current_name = $row['category_name'];
    }
} else {
    echo "invalid id";
}


if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $new_name = $_POST['category'];

    $sql = "UPDATE category SET category_name = '$new_name' WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        header("location: category.php");
    } else {
        echo "The query is not correct";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Categories</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Bootstrap JS Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- bootstrap icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets2/styles.css" />
</head>

<body>

    <!-- Sidebar will be injected here -->
    <div class="toggle-btn" id="toggleBtn">
        <i class="fas fa-bars"></i>
    </div>

    <?php include "../includes/sidebar.php"; ?>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div id="mainHeader" class="header d-flex justify-content-between align-items-center px-4 py-2 bg-white border-bottom shadow-sm  w-100">
            <h4 class="fw-bold mb-0">Update Category</h4>
            <?php include "../users/nav_profile.php"; ?>
        </div>

        <!-- Push content below fixed header -->
        <div style="padding-top: 30px;"></div>

        <div class="container-fluid px-3">
            <?php if ($role == "admin") : ?>
                <div class="card shadow-sm rounded-4 mt-4">
                    <div class="card-body">

                        <form action="" method="post" id="categoryForm">
                            <!-- Row with two columns: Input & Button -->
                            <div class="row g-3">
                                <!-- Brand Name -->
                                <div class="col-md-9">
                                    <label for="categoryInput" class="form-label">Category Name</label>
                                    <input type="text" id="category" name="category" class="form-control" value="<?php echo $current_name ?>" placeholder="New Category name">
                                    <div id="nameErr" class="text-start invalid-feedback"></div>
                                </div>

                                <!-- Add Button -->
                                <div class="col-md-3 d-flex align-items-end">
                                    <button type="submit" class="btn custom-orange-btn">Update</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- Script -->
    <script src="../assets2/script.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            $("#categoryForm").on("submit", function(e) {
                let category = $("#category").val().trim();
                if (category == "") {
                    $("#category").addClass("is-invalid");
                    $("#nameErr").text("Please enter a valid name");
                    e.preventDefault();
                } else {
                    $("#nameErr").text("");
                }
            });
        });
    </script>
</body>

</html>