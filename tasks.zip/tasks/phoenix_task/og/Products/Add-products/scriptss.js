
//for uploading image in add products page
const uploadInput = document.getElementById("product-file-upload");
const preview = document.getElementById("preview");

uploadInput.addEventListener("change", (event) => {
  const file = event.target.files[0]; // Get only the first selected file
  if (!file) return;

  preview.innerHTML = ""; // Clear any previous preview

  const reader = new FileReader();
  reader.onload = () => {
    const col = document.createElement("div");
    col.className = "col-12";

    const img = document.createElement("img");
    img.src = reader.result;
    img.className = "img-fluid rounded shadow-sm mb-2";
    img.alt = file.name;

    col.appendChild(img);
    preview.appendChild(col);
  };

  reader.readAsDataURL(file);
});


function addField() {
  const container = document.getElementById('product-warehouseStockFields');
  const newRow = document.createElement('div');
  newRow.classList.add('row', 'warehouse-entry');

  newRow.innerHTML = `
                <div class="row g-2 align-items-end mb-2">
                    <div class="col-md-6">
                      <select class="form-select" name="warehouse[]">
                        <option value="">-- Select Warehouse --</option>
                        <option value="Warehouse A">Warehouse A</option>
                        <option value="Warehouse B">Warehouse B</option>
                        <option value="Warehouse C">Warehouse C</option>
                      </select>
                    </div>
                    <div class="col-md-4">
                      <input type="number" class="form-control" placeholder="Stock" name="stock[]">
                    </div>
                    <div class="col-md-2 d-flex">
                      <button type="button" class="btn btn-success btn-sm me-1" onclick="addField()">
                        <i class="fas fa-plus"></i>
                      </button>

<!-- Remove Button -->
                        <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.row').remove()">
                          <i class="fas fa-minus"></i>
                        </button>
                        </div>
  `;

  container.appendChild(newRow);
}
