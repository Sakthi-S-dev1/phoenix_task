
function addField() {
    const container = document.getElementById('addStockWarehouseFields');
    const newRow = document.createElement('div');
    newRow.classList.add('row', 'warehouse-entry');
  
    newRow.innerHTML = `
      <div class="row g-2 align-items-end mb-3">
            <div class="col-md-5">
              <label class="form-label">Select Warehouse</label>
              <select class="form-select" name="warehouse[]">
                <option value="">-- Select Warehouse --</option>
                <option value="Warehouse A">Warehouse A</option>
                <option value="Warehouse B">Warehouse B</option>
                <option value="Warehouse C">Warehouse C</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Stock</label>
              <input type="number" class="form-control" placeholder="Stock" name="stock[]">
            </div>
            <div class="col-md-3 d-flex gap-2">
              <button type="button" class="btn btn-success" onclick="addField()"><i class="fas fa-plus"></i></button>
              <button type="button" class="btn btn-danger" onclick="this.closest('.row').remove()"><i class="fas fa-minus"></i></button>
            </div>
          </div>
        </div>
    `;
  
    container.appendChild(newRow);
  }
   
  function openModal() {
    const modal = new bootstrap.Modal(document.getElementById('stockModal1'));
    modal.show();
  }
