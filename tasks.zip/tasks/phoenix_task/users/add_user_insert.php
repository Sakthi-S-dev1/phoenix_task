<?php
require "../db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);
    $password = trim($_POST['password']);
    $state = trim($_POST['state']);
    $city = trim($_POST['city']);
    $pincode = trim($_POST['pincode']);
    $role = trim($_POST['role']);

    if (empty($username) || empty($phone) || empty($email)) {
        echo "Please fill all required fields.";
        exit;
    }

    $sql = "INSERT INTO users (username, phone, email,password, address, state, city, pincode,role)
            VALUES ('$username','$phone','$email','$password','$address','$state','$city','$pincode','$role')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "success";
    } else {
        echo "Failed to add user.";
    }
}
?>
