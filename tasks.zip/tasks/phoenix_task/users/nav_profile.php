<?php
$prefix = '';
if (basename($_SERVER['PHP_SELF']) !== 'index.php') {
  $prefix = '../';
}
?>
<div id="profile" class="d-flex align-items-center gap-3">
  <span>Welcome, <?= $_SESSION['user_name']; ?></span>

  <i id="notificationBell" class="bi bi-bell fs-4 me-2" style="cursor: pointer;"></i>


  <div class="dropdown">
    <i id="profileIcon"
      class="bi bi-person-circle fs-4"
      style="cursor: pointer;"
      data-bs-toggle="dropdown"
      aria-expanded="false"></i>

    <ul class="dropdown-menu dropdown-menu-end shadow-sm" aria-labelledby="profileIcon">
      <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i>Profile</a></li>
      <li><a class="dropdown-item text-danger" href="<?php echo $prefix ?>logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
    </ul>
  </div>

</div>