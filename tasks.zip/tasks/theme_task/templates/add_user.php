<?php
require "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = trim($_POST['name']);
    $age      = (int)trim($_POST['age']);
    $email    = trim($_POST['email']);
    $phone    = trim($_POST['phone']);
    $password = trim($_POST['password']);
    $role     = trim($_POST['role']);

    /* var_dump($_POST);
    exit; */

    $check_email = "SELECT * FROM test WHERE email = '$email'";
    $check_result = mysqli_query($conn, $check_email);

    if (mysqli_num_rows($check_result) > 0) {
        echo "<script>alert('Email already exists!'); history.back();</script>";
        exit;
    }
    
    $sql = "INSERT INTO test (name, age, email, phone, role, password)
            VALUES ('$name','$age','$email','$phone','$role','$password')";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "<script>alert('register added successfully!'); window.location='view.php';</script>";
        exit;
    } else {
        echo "error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from polygons.space/connect/theme/templates/admin1/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 26 Jul 2025 08:05:49 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Responsive Admin Dashboard Template">
    <meta name="keywords" content="admin,dashboard">
    <meta name="author" content="stacks">
    <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Connect - Responsive Admin Dashboard Template</title>

    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/plugins/font-awesome/css/all.min.css" rel="stylesheet">


    <!-- Theme Styles -->
    <link href="../assets/css/connect.min.css" rel="stylesheet">
    <link href="../assets/css/dark_theme.css" rel="stylesheet">
    <link href="../assets/css/custom.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>

<body>
    <div class='loader'>
        <div class='spinner-grow text-primary' role='status'>
            <span class='sr-only'>Loading...</span>
        </div>
    </div>

    <div class="connect-container align-content-stretch d-flex flex-wrap">
        <div class="page-sidebar">
            <?php
            include "sidebar.php";
            ?>
        </div>

        <div class="page-container">
            <div class="page-header">

                <?php
                include "navbar.php";
                ?>

            </div>
            <div class="page-content">
                <div class="card">
                    <div class="card-body">
                        <div class="main-wrapper">
                            <form action="" class="form" method="post">
                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="" class="form-label">Name</label>
                                        <input type="text" name="name" id="name" class="form-control">
                                        <div class="invalid-feedback" id="nameError"></div>
                                    </div>
                                    <div class="col">
                                        <label for="" class="form-label">Age</label>
                                        <input type="number" name="age" id="age" class="form-control">
                                        <div class="invalid-feedback" id="ageError"></div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="" class="form-label">Email</label>
                                        <input type="email" name="email" id="email" class="form-control">
                                        <div class="invalid-feedback" id="emailError"></div>
                                    </div>
                                    <div class="col">
                                        <label for="" class="form-label">Phone</label>
                                        <input type="number" name="phone" id="phone" class="form-control">
                                        <div class="invalid-feedback" id="phoneError"></div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="" class="form-label">Password</label>
                                        <input type="password" name="password" id="password" class="form-control">
                                        <div class="invalid-feedback" id="passwordError"></div>
                                    </div>
                                    <div class="col">
                                        <label for="" class="form-label">Confirm Password</label>
                                        <input type="password" name="cpassword" id="cpassword"  class="form-control">
                                        <div class="invalid-feedback" id="cpasswordError"></div>
                                    </div>
                                </div>
                                    <select name="role" id="role" class="form-select form-control mt-4" required>
                                        <option class="" value="">--Select Role--</option>
                                        <option value="user">User</option>
                                        <option value="admin">Admin</option>
                                    </select>
                                <div class="mt-5 text-center ">
                                    <button type="submit" class="btn btn-primary">ADD USER</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="page-footer">
                <?php
                include "footer.php";
                ?>
            </div>
        </div>
    </div>

    <!-- Javascripts -->
    <script src="../assets/plugins/jquery/jquery-3.4.1.min.js"></script>
    <script src="../assets/plugins/bootstrap/popper.min.js"></script>
    <script src="../assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="../assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <script src="../assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="../assets/plugins/apexcharts/dist/apexcharts.min.js"></script>
    <script src="../assets/plugins/blockui/jquery.blockUI.js"></script>
    <script src="../assets/plugins/flot/jquery.flot.min.js"></script>
    <script src="../assets/plugins/flot/jquery.flot.time.min.js"></script>
    <script src="../assets/plugins/flot/jquery.flot.symbol.min.js"></script>
    <script src="../assets/plugins/flot/jquery.flot.resize.min.js"></script>
    <script src="../assets/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="../assets/js/connect.min.js"></script>
    <script src="../assets/js/pages/dashboard.js"></script>

    <script>
        $(document).ready(function() {
            const namePattern = /^[a-zA-Z\s]+$/;
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const phonePattern = /^[0-9]{10}$/;

            $("#r_form").on("submit", function(e) {
                let name = $("#name").val().trim();
                let age = $("#age").val().trim();
                let email = $("#email").val().trim();
                let phone = $("#phone").val().trim();
                let password = $("#password").val();
                let cpassword = $("#cpassword").val();
                let role = $("#role").val();

                let isValid = true;

                // Name
                if (name === "" || !namePattern.test(name)) {
                    $("#name").addClass("is-invalid");
                    $("#nameError").text("Please enter a valid name.");
                    isValid = false;
                } else {
                    $("#name").removeClass("is-invalid");
                    $("#nameError").text("");
                }

                // Age
                if (age === "" || isNaN(age) || age < 1 || age > 120) {
                    $("#age").addClass("is-invalid");
                    $("#ageError").text("invalid age");
                    isValid = false;
                } else {
                    $("#age").removeClass("is-invalid");
                }

                // Email
                if (!emailPattern.test(email)) {
                    $("#email").addClass("is-invalid");
                    $("#emailError").text("invalid email")
                    isValid = false;
                } else {
                    $("#email").removeClass("is-invalid");
                }

                // Phone
                if (!phonePattern.test(phone)) {
                    $("#phone").addClass("is-invalid");
                    $("#phoneError").text("invalid phone")
                    isValid = false;
                } else {
                    $("#phone").removeClass("is-invalid");
                }

                // Password
                if (password.length < 6) {
                    $("#password").addClass("is-invalid");
                    $("#passwordError").text("invalid password")
                    isValid = false;
                } else {
                    $("#password").removeClass("is-invalid");
                }

                if(password !== cpassword){
                    $("#cpasswordError").text("password does not match");
                    $("#cpassword").addClass("is-invalid");
                    isValid = false;
                }

                // Role
                if (role === "") {
                    $("#role").addClass("is-invalid");
                    isValid = false;
                } else {
                    $("#role").removeClass("is-invalid");
                }

                // Final check
                if (!isValid) {
                    e.preventDefault();
                }
                else{
                    this.submit();
                }
            });
        });
    </script>
</body>

<!-- Mirrored from polygons.space/connect/theme/templates/admin1/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 26 Jul 2025 08:05:49 GMT -->

</html>