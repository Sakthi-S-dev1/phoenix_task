<?php 
    require "db.php";
    $id = $_GET['id'];

    if(isset($id) && !empty($id)){
        $sql = "DELETE FROM test WHERE id='$id'";
        $result = mysqli_query($conn,$sql);

        if($result){
            echo "1 row(s) is deleted successfully";
            header("location: view.php");
            exit;
        }
    }
?>