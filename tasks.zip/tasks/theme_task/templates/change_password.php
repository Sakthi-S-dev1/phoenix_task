<?php
require "db.php";

if (!isset($_GET['email'])) {
    echo "Invalid access.";
    exit;
}

$email = mysqli_real_escape_string($conn, $_GET['email']);
$default_pass = "1234567890sak";

// Fetch user
$sql = "SELECT * FROM test WHERE email = '$email'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if (!$row) {
    echo "User not found.";
    exit;
}

// Calculate days since last password change
if (!empty($row['password_changed_at'])) {
    $last_changed = strtotime($row['password_changed_at']);
    $now = time();
    $days_ago = floor(($now - $last_changed) / 86400); // 86400 seconds = 1 day

    if (($now - $last_changed) < 86400) { // less than 1 day
        echo "You already changed your password recently.<br>";
        echo "Last changed: <b>" . date("d M Y h:i A", $last_changed) . "</b><br>";
        echo "Password: <b>" . htmlspecialchars($row['password']) . "</b><br>";
        echo "You changed your password <b>$days_ago day(s)</b> ago.";
        exit;
    }
} else {
    $days_ago = "Never";
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_pass = trim($_POST['new_password']);

    if ($new_pass === "") {
        echo "<script>alert('Password cannot be empty');</script>";
    } elseif ($new_pass === $row['password']) {
        echo "<script>alert('New password cannot be the same as old password');</script>";
    } elseif ($new_pass === $default_pass) {
        echo "<script>alert('You cannot reuse the default password');</script>";
    } 
    
    else {
        $update_sql = "UPDATE test SET password = '$new_pass', password_changed_at = NOW() WHERE email = '$email'";
        if (mysqli_query($conn, $update_sql)) {
            echo "<script>alert('Password changed successfully. Redirecting to login...');</script>";
            header("refresh:1;url=index.php");
            exit;
        } else {
            echo "<script>alert('Failed to update password.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from polygons.space/connect/theme/templates/admin1/sign-in.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 26 Jul 2025 08:07:22 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Responsive Admin Dashboard Template">
    <meta name="keywords" content="admin,dashboard">
    <meta name="author" content="stacks">
    <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Connect - Responsive Admin Dashboard Template</title>

    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/plugins/font-awesome/css/all.min.css" rel="stylesheet">


    <!-- Theme Styles -->
    <link href="../assets/css/connect.min.css" rel="stylesheet">
    <link href="../assets/css/dark_theme.css" rel="stylesheet">
    <link href="../assets/css/custom.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>

<body class="auth-page sign-in">

    <div class='loader'>
        <div class='spinner-grow text-primary' role='status'>
            <span class='sr-only'>Loading...</span>
        </div>
    </div>
    <div class="connect-container align-content-stretch d-flex flex-wrap">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-5">
                    <div class="auth-form">
                        <div class="row">
                            <div class="col">
                                <div class="logo-box"><a href="#" class="logo-text">Change Password</a></div>
                                <form action="" method="post">

                                    <div class="form-group">
                                        <?php if ($days_ago !== "Never"): ?>
                                            <p>Last password change was <b><?php echo $days_ago; ?> day(s) ago</b> on <b><?php echo date("d M Y h:i A", $last_changed); ?></b>.</p>
                                        <?php else: ?>
                                            <p>You have never changed your default password.</p>
                                        <?php endif; ?>
                                        <input type="password" name="new_password" class="form-control" placeholder="Enter New Password" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-block btn-submit">Change Password</button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 d-none d-lg-block d-xl-block">
                    <div class="auth-image"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascripts -->
    <script src="../assets/plugins/jquery/jquery-3.4.1.min.js"></script>
    <script src="../assets/plugins/bootstrap/popper.min.js"></script>
    <script src="../assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="../assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <script src="../assets/js/connect.min.js"></script>
</body>

<!-- Mirrored from polygons.space/connect/theme/templates/admin1/sign-in.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 26 Jul 2025 08:07:22 GMT -->

</html>