<?php
require "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    if ($email === "" || $password === "") {
        echo "<script>alert('All fields are required'); history.back();</script>";
        exit;
    }

    $sql = "SELECT * FROM test WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);

    if ($row = mysqli_fetch_assoc($result)) { 
        if ($password === "1234567890sak") {
            // Force redirect to change password if default is used
            header("Location: change_password.php?email=$email");
            exit;
        }

        if ($password === $row['password']) {
            $role = $row['role'];

            if ($role === "admin") {
                header("Location: dashboard.php");
                exit;
            } elseif ($role === "user") {
                header("Location: user_profile.php");
                exit;
            } else {
                echo "<script>alert('Unknown role'); history.back();</script>";
                exit;
            }
        } else {
            echo "<script>alert('Invalid password'); history.back();</script>";
            exit;
        }
    } else {
        echo "<script>alert('No account found for this email'); history.back();</script>";
        exit;
    }
}
?>
