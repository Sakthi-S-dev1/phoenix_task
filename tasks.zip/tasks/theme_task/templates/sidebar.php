<div class="logo-box">
    <a href="#" class="logo-text">Connect</a>
    <a href="#" id="sidebar-close"><i class="material-icons">close</i></a> 
    <a href="#" id="sidebar-state"><i class="material-icons">adjust</i>
    <i class="material-icons compact-sidebar-icon">panorama_fish_eye</i></a>
</div>
<div class="page-sidebar-inner slimscroll">
    <ul class="accordion-menu">
        <li>
            <a href="dashboard.php" class="active"><i class="material-icons-outlined">dashboard</i>Dashboard</a>
        </li>

        <li>
            <a href="#">Users<i class="material-icons has-sub-menu">add</i></a>
            <ul class="sub-menu">
                <li>
                    <a href="add_user.php">Add User</a>
                </li>
                <li>
                    <a href="view.php">View Users</a>
                </li>
            </ul>
        </li>


    </ul>
</div>