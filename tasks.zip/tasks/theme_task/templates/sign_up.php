<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from polygons.space/connect/theme/templates/admin1/sign-up.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 26 Jul 2025 08:07:22 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Responsive Admin Dashboard Template">
    <meta name="keywords" content="admin,dashboard">
    <meta name="author" content="stacks">
    <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Connect - Responsive Admin Dashboard Template</title>

    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/plugins/font-awesome/css/all.min.css" rel="stylesheet">


    <!-- Theme Styles -->
    <link href="../assets/css/connect.min.css" rel="stylesheet">
    <link href="../assets/css/dark_theme.css" rel="stylesheet">
    <link href="../assets/css/custom.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>

<body class="auth-page sign-in">

    <div class='loader'>
        <div class='spinner-grow text-primary' role='status'>
            <span class='sr-only'>Loading...</span>
        </div>
    </div>
    <div class="connect-container align-content-stretch d-flex flex-wrap">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-5">
                    <div class="auth-form">
                        <div class="row">
                            <div class="col">
                                <div class="logo-box"><a href="#" class="logo-text">Connect</a></div>
                                <form id="r_form" action="sign_up_insert.php" method="post">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="name" id="name" placeholder="Enter name">
                                        <div id="nameError" class="invalid-feedback"></div>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="age" id="age" placeholder="Enter age">
                                        <div id="ageError" class="invalid-feedback"></div>
                                    </div>
                                    <div class="form-group">
                                        <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
                                        <div id="emailError" class="invalid-feedback"></div>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="phone" id="phone" placeholder="Enter phone">
                                        <div id="phoneError" class="invalid-feedback"></div>
                                    </div>

                                    <!-- <div class="form-group">
                                        <input type="password" class="form-control" name="password" id="password" placeholder="password">
                                        <div id="passwordError" class="invalid-feedback"></div>
                                    </div> -->
                                    
                                    <select name="role" id="role" class="form-control" required>
                                        <option class="" value="">--select role--</option>
                                        <option class="" value="user">user</option>
                                        <option class="" value="admin">admin</option>
                                    </select>

                                    <button type="submit" class="btn btn-primary btn-block btn-submit">Sign-Up</button>
                                    <div class="auth-options">
                                        <div class="custom-control custom-checkbox form-group">
                                            <input type="checkbox" class="custom-control-input" id="exampleCheck1">
                                            <label class="custom-control-label" for="exampleCheck1">Sign me in</label>
                                        </div>
                                        <a href="index.php" class="forgot-link">Already have an account?</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 d-none d-lg-block d-xl-block">
                    <div class="auth-image"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascripts -->
    <script src="../assets/plugins/jquery/jquery-3.4.1.min.js"></script>
    <script src="../assets/plugins/bootstrap/popper.min.js"></script>
    <script src="../assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="../assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <script src="../assets/js/connect.min.js"></script>
    <script>
        $(document).ready(function() {
            const namePattern = /^[a-zA-Z\s]+$/;
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const phonePattern = /^[0-9]{10}$/;

            $("#r_form").on("submit", function(e) {
                let name = $("#name").val().trim();
                let age = $("#age").val().trim();
                let email = $("#email").val().trim();
                let phone = $("#phone").val().trim();
                let password = $("#password").val();
                let role = $("#role").val();

                let form = true;

                if (name === "" || !namePattern.test(name)) {
                    $("#name").addClass("is-invalid");
                    $("#nameError").text("Please enter a valid name.");
                    form = false;
                } else {
                    $("#name").removeClass("is-invalid");
                    $("#nameError").text("");
                }

                if (age === "" || isNaN(age) || age < 18 ) {
                    $("#age").addClass("is-invalid");
                    $("#ageError").text("Invalid age");
                    form = false;
                } else {
                    $("#age").removeClass("is-invalid");
                    $("#ageError").text("");
                }

                if (!emailPattern.test(email)) {
                    $("#email").addClass("is-invalid");
                    $("#emailError").text("Invalid email");
                    form = false;
                } else {
                    $("#email").removeClass("is-invalid");
                    $("#emailError").text("");
                }

                if (!phonePattern.test(phone)) {
                    $("#phone").addClass("is-invalid");
                    $("#phoneError").text("Invalid phone");
                    form = false;
                } else {
                    $("#phone").removeClass("is-invalid");
                    $("#phoneError").text("");
                }

                /* if (password.length < 6) {
                    $("#password").addClass("is-invalid");
                    $("#passwordError").text("Invalid password");
                    form = false;
                } else {
                    $("#password").removeClass("is-invalid");
                    $("#passwordError").text("");
                } */

                if (role === "") {
                    $("#role").addClass("is-invalid");
                    form = false;
                } else {
                    $("#role").removeClass("is-invalid");
                }

                if (!form) {
                    e.preventDefault();
                }
            });

        });
    </script>
</body>

<!-- Mirrored from polygons.space/connect/theme/templates/admin1/sign-up.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 26 Jul 2025 08:07:22 GMT -->

</html>