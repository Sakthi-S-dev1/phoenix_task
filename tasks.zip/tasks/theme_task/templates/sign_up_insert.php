<?php
require "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = trim($_POST['name']);
    $age      = (int)trim($_POST['age']);
    $email    = trim($_POST['email']);
    $phone    = trim($_POST['phone']);
    $role     = trim($_POST['role']);

    $default_pass = "1234567890sak";

    // Save data to DB
    $sql = "INSERT INTO test (name, age, email, phone, role, password) 
            VALUES ('$name', '$age', '$email', '$phone', '$role', '$default_pass')";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        echo "<script>
                alert('Database Error');
                window.location.href = 'sign_up.php';
              </script>";
        exit;
    }

    $subject = "Login Verification";
    $link = "http://localhost/tasks/theme_task/templates/change_password.php?email=$email";

    $message = "Hello $name,\n\n";
    $message .= "Your default password is: $default_pass\n\n";
    $message .= "Click this link to change your password:\n$link";

    $headers = "From: sakthi.ctrlnxt@gmail.com";

    if (mail($email, $subject, $message, $headers)) {
        echo "<script>
                alert('Email sent successfully');
                window.location.href = '$link';
              </script>";
    } else {
        error_log("Mail failed to send to $email");
        echo "<script>
            alert('Failed to send email');
            window.location.href = 'sign_up.php';
          </script>";
    }
    exit;
}
