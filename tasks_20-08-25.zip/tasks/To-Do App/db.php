<?php
$conn = mysqli_connect("localhost","root","","my_projects");
if(!$conn){
    die("this db not connected". mysqli_connect_error());
}
?>