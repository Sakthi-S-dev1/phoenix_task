<?php
require "db.php";
$sql = "SELECT * FROM admin";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container-fluid w-75 my-5">
        <div class="">
            <h2>Admin panel Dashboard</h2>
            <span><a href="register.php" class="btn btn-success float-end">New</a></span>
            
            <a href="export_excel.php" class="btn btn-success">Export as Excel</a>
            <a href="export_pdf.php" class="btn btn-danger">Export as PDF</a>

        </div>
        <table class="table table-hover">
            <thead>
                <th>ID</th>
                <th>Name</th>
                <th>Profile</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Role</th>
                <th>Actions</th>
            </thead>
            <tbody>
                <?php
                    if(mysqli_num_rows($result) > 0){
                        while($row = mysqli_fetch_assoc($result)){
                ?>
                <tr>
                    <?php
                        echo "<td>".$row['id']."</td>";
                        echo "<td>".$row['Name']."</td>";
                        echo "<td>".$row['Profile']."</td>";
                        echo "<td>".$row['Email']."</td>";
                        echo "<td>".$row['Phone']."</td>";
                        echo "<td>".$row['Role']."</td>";
                        echo "<td>";
                            echo "<a href='update.php?id=".$row['id']."' class='btn btn-primary' >Update</a> / ";
                            echo "<a href='delete.php?id=".$row['id']."' class='btn btn-danger' >Delete</a>";
                        echo "</td>";                        
                    ?>
                </tr>
                    <?php
                    }//while lopp
                }// if condition
                    ?>
            </tbody>
        </table>
    </div>
</body>
</html>