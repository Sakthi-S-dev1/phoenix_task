<?php
$conn = new mysqli("localhost", "root", "", "df");
if($conn->connect_error){
    die("database not connected".$conn->connect_error);
}
?>