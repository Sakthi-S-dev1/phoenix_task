<?php
require "db.php";
$id = $_GET['id'];
if(isset($id) && !empty($id)){
$sql="DELETE FROM admin WHERE id='$id' ";
$result = mysqli_query($conn, $sql);
if($result){
    echo "1 row deleted successfully";
    header("location: dashboard.php");
    exit();
}
echo "query error";
}
else{ echo "id not valid"; }

?>