<?php
require  "db.php";
 
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $role = $_POST['role'];

    $pass = password_hash($_POST['pass'],PASSWORD_DEFAULT);

    $filename = "";

    if(isset($_FILES['profile']) && $_FILES['profile']['error'] == 0){
        $filename = $_FILES['profile']['name'];
        $tmp = $_FILES['profile']['tmp_name'];
        $folder = "uploads/";
        $allowed = ['jpg','jpeg','png','gif'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if(in_array($ext, $allowed)){
            $new_file_name = "img_".time().".".$ext;
            $path = $folder.$new_file_name;
            if(move_uploaded_file($tmp, $path)){
                $filename = $new_file_name;
            }
            else{
                echo "file not moved";
            }
        }
        else{
            echo "only jpg jpeg gif png is allowed";
        }
    }

    $query = "INSERT INTO admin(Name,Profile,Email,Phone,Password,Role) VALUES('$name','$filename','$email','$phone','$pass','$role')";
    $result = mysqli_query($conn, $query);
    if($result){
        echo "data inserted successfully";
    }
    else{
        echo "data is not inserted";
    }
?>