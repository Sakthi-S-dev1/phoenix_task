<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container-fluid w-75 my-5">
        <h2>Registration Form</h2>
        <form class="form" id="r-form" action="" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control " id="name" name="name">
                <span class="error invalid-feedback " id="nameError"></span>
            </div>
            <div class="form-group">
                <label for="email" class="form-label">E-mail</label>
                <input type="email" class="form-control" id="email" name="email">
                <span class="error invalid-feedback " id="emailError"></span>
            </div>
            <div class="form-group">
                <label for="phone" class="form-label">Phone</label>
                <input type="number" class="form-control" id="phone" name="phone">
                <span class="error invalid-feedback " id="phoneError"></span>
            </div>
            <div class="form-group">
                <label for="pass" class="form-label">Password</label>
                <input type="password" class="form-control" id="pass" name="pass">
                <span class="error invalid-feedback " id="passError"></span>
            </div>
            <div class="form-group">
                <label for="profile" class="form-label">Profile</label>
                <input type="file" class="form-control" id="profile" name="profile">
                <span class="error invalid-feedback " id="profileError"></span>
            </div><br>
            <div class="form-group ">
                <select name="role" id="role" class="form-select">
                    <option value="">--Select Role--</option>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
                <span class="error invalid-feedback" id="roleError"></span>
            </div>
            <div class="button text-center mt-5">
                <button type="submit" id="submit" class="btn btn-success">Submit</button>
                <button class="btn btn-primary" id="login">Log-In</button>
            </div>
        </form>
    </div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.19.3/jquery.validate.min.js"></script>
<script>
$(document).ready(function(){
    function validName(){
        let inputName = $("#name").val().trim();
        let namePattern = /^[a-zA-Z\s]+$/;

        $("#name").removeClass("is-invalid");
        $("#nameError").text("");

        if(inputName === ''){
            $("#nameError").text("name is required");
            $("#name").addClass("is-invalid");
            return false;
        } else if(!namePattern.test(inputName)){
            $("#nameError").text("name only contain letters and spaces");
            $("#name").addClass("is-invalid");
            return false;
        }
         return true;
    };

    function validEmail(){
        let inputEmail = $("#email").val().trim();
        let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        $("#email").removeClass("is-invalid");
        $("#emailError").text("");

        if(inputEmail === ''){
            $("#emailError").text("your email is required.");
            $("#email").addClass("is-invalid");
            return false;
        }else if(!emailPattern.test(inputEmail)){
            $("#emailError").text("please enter the valid email.");
            $("#email").addClass("is-invalid");
            return false;
        }
         return true;
    }

    function validPhone(){
        let inputPhone = $("#phone").val().trim();

        $("#phone").removeClass("is-invalid");
        $("#phoneError").text("");

        if(inputPhone === ''){
            $("#phoneError").text("phone number is required.");
            $("#phone").addClass("is-invalid");
            return false;
        }
        else if(!/^\d{10}$/.test(inputPhone)){  
            $("#phoneError").text("length should be 10.");
            $("#phone").addClass("is-invalid");
            return false;
        }
         return true;
    }

    function validPass(){
        let inputPass = $("#pass").val().trim();
        $("#pass").removeClass("is-invalid");
        $("#passError").text("");

        if(inputPass === ''){
            $("#passError").text("please enter the password.");
            $("#pass").addClass("is-invalid");
            return false;
        }
        else if(inputPass.length < 6){
            $("#passError").text("allowed minimum 6 characters");
            $("#pass").addClass("is-invalid");
            return false;
        }
        return true;
    }
    
    function validRole(){
        let inputRole = $("#role").val();
        $("#role").removeClass("is-invalid");

        if(inputRole == ''){
            $("#roleError").text("please select your Role.");
            $("#role").addClass("is-invalid");
            return false;
        }
        return true;
    }

    $("#name").on("input", validName);
    $("#email").on("input", validEmail);
    $("#phone").on("input", validPhone);
    $("#pass").on("input", validPass);
    $("#role").on("click", validRole);

    $("#submit").click(function(e) {
        e.preventDefault();

        let inputName = validName();
        let inputEmail = validEmail();
        let inputPhone = validPhone();
        let inputPass = validPass();
        let inputRole = validRole();

        if (!inputName || !inputEmail || !inputPhone || !inputPass || !inputRole) {
            alert("errors in the form.");
            return;
        }

        let formData = new FormData($("#r-form")[0]);

        $.ajax({
            url: "insert.php",
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function(res){
                alert(res);
                $("#r-form")[0].reset();
            },
            error: function(){
                alert("Something went wrong while submitting.");
            }
        });
    });

    $("#login").click(function(e){
        e.preventDefault();
        window.location.href = "login.php";
    });


});

</script>

</body>
</html>