<?php
require "config.php";
    $id =$_GET['id'];
    //get the old data 
    $sql = "SELECT * FROM students WHERE id=$id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result);
    $curr_img =$row['profile'];

    if($_SERVER["REQUEST_METHOD"]=="POST"){

        if(isset($_FILES['n_pic']) && $_FILES['n_pic']['error'] == 0){
            //delete old imge if exsist in folder
            if($curr_img && file_exists("assets/".$curr_img)){
                unlink('assets/'.$curr_img);
            }
            //new file updation
            $filename = $_FILES['n_pic']['name'];
            $tmp = $_FILES['n_pic']['tmp_name'];
            $ext = strtolower(pathinfo($filename,PATHINFO_EXTENSION));
            $new_pic_name = "img_".time().".".$ext;
            $folder = "assets/".$new_pic_name;
            move_uploaded_file($tmp,$folder);
            $sql = "UPDATE students SET profile='$new_pic_name' WHERE id =$id";
            if($result = mysqli_query($conn, $sql)){
                echo "image updated";
            }

        }
        function check($d){
            $d = htmlspecialchars(trim($d));
            return $d;
        }
        $new_name = $_POST['n_name'];
        $new_age = $_POST['n_age'];
        $new_email = $_POST['n_email'];

        //

        if(empty(check($new_name)) || empty(check($new_age)) || empty(check($new_email))){
            echo "all feilds are required";
        }

        else{
            $sql="UPDATE students SET name='$new_name', age='$new_age', email='$new_email' WHERE id=$id ";
            $result = mysqli_query($conn, $sql);
            if($result){
                header("location: index.php");
                exit();
            }
        }
    }
?>
<form action="" method="post" enctype="multipart/form-data">
    name : <input type="text" name="n_name" value="<?php echo $row['name'] ?>"><br><br>
    age : <input type="text" name="n_age" value="<?php echo $row['age'] ?>"><br><br>
    email : <input type="text" name="n_email" value="<?php echo $row['email'] ?>"><br><br>
    new pic : <input type="file" name="n_pic" value="<?php echo $row['profile'] ?>"><br><br>
    <button type="submit">Update</button>
</form>