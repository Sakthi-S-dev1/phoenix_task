<?php
require "config.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    $stmt = mysqli_prepare($conn, "SELECT profile_img FROM users WHERE id=?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $img = $row['profile_img'];
        if ($img && file_exists("uploads/$img")) {
            unlink("uploads/$img");
        }

        $update = mysqli_prepare($conn, "UPDATE users SET profile_img='' WHERE id=?");
        mysqli_stmt_bind_param($update, "i", $id);
        if (mysqli_stmt_execute($update)) {
            echo "success";
            exit;
        }
    }
}
echo "error";
