<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .wrapper{
            width: 1000px;
            margin: 0 auto;
        }
        table tr td:last-child{
            text-align:center;
            width: 120px;
        }
        table tr th,td{
            text-align:center;
        }
        .i-hover:hover{
            box-shadow:0 0 20px rgba(0,0,0,0.5);
            transition: .4s ease;
        }
    </style>
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-5 mb-3 clearfix">
                        <h2 class="pull-left">User details</h2>
                        <a href="create.php" class="btn btn-success pull-right">Add user</a>
                    </div>
                    <?php 
                        require "config.php";
                        $sql = "SELECT * FROM users";
                        $result = mysqli_query($conn,$sql);
                        if($result){
                            if(mysqli_num_rows($result) > 0){
                                echo "<table class='table table-bordered table-striped'>";
                                    echo "<thead>";
                                        echo "<tr>";
                                            echo "<th>#id</th>";
                                            echo "<th>Profile Pic</th>";
                                            echo "<th>Pic Name</th>";
                                            echo "<th>Full Name</th>";
                                            echo "<th>Username</th>";
                                            echo "<th>E-mail id</th>";
                                            echo "<th>Actions</th>";
                                        echo "</tr>"; 
                                    echo "</thead>";
                                    echo "<tbody>";

                                        while($row = mysqli_fetch_array($result)){
                                            echo "<tr>";
                                                echo "<td>".$row['id']."</td>";
                                                echo "<td><img src='uploads/".$row['profile_img']."' width='75' height='75' style=' object-fit:cover' class='rounded i-hover' alt='image'></td>";
                                                echo "<td>".$row['profile_img']."</td>";
                                                echo "<td>".$row['full_name']."</td>";
                                                echo "<td>".$row['username']."</td>";
                                                echo "<td>".$row['email']."</td>";
                                                echo "<td>";
                                                    echo '<a href="read.php?id='. $row['id'] .'" class="mr-3" title="View Record" data-toggle="tooltip"><span class="fa fa-eye"></span></a>';
                                                    echo '<a href="update.php?id='. $row['id'] .'" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-pencil"></span></a>';
                                                    echo '<a href="delete.php?id='.$row['id'].'" class="" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>';
                                                echo "</td>";
                                            echo "</tr>";
                                        }
                                    echo "</tbody>";
                                echo "</table>";
                                mysqli_free_result($result);
                            }
                            else{
                                echo '<div class="alert alert-danger"><em>No Records found.</em></div>';
                            }
                            }
                            else{
                                echo "somthing whent wrong try again later";
                            }
                            
                        
                        mysqli_close($conn);
                    ?>
                </div>
            </div>
        </div>
    </div>
</body>
