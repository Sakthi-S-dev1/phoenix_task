<?php
if(isset($_GET['id']) && !empty($_GET['id']))
{
    require "config.php";
    //prepare a select statement
    $sql = "SELECT * FROM users WHERE id =?";
    $stmt = mysqli_prepare($conn,$sql);
    if($stmt){
        mysqli_stmt_bind_param($stmt,"i",$param_id);
        $param_id = trim($_GET['id']);
        //attempt to execute the p-stmt
        if(mysqli_stmt_execute($stmt))
        {
            $result = mysqli_stmt_get_result($stmt);

            if(mysqli_num_rows($result)==1){
                //stores as array
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                //values from db
                $fname = $row['full_name'];
                $uname = $row['username'];
                $email = $row['email'];
                $pass = $row['password'];
                $profile = $row['profile_img'];

            }
            else{
                header("location: error.php");
                exit();
            }
        }
            else{
                echo "somthing went wrong, try again later";
            }
        }
        //close statement
        mysqli_stmt_close($stmt);

        mysqli_close($conn);
}
    else{
        header("location: error.php");
        exit();
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
        .img{
            width: 200px;
            height: 200px;
            border-radius:50%;
            float:right;
            border:5px solid whitesmoke;
        }
        .img:hover {
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            transition: box-shadow 0.5s ease;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-5 mb-3">View record</h1>
                    
                    <div class="form-group">
                        <img src="uploads/<?php echo $row['profile_img']; ?>" alt="profile image" class="img">
                    </div>

                    <div class="form-group">
                        <label for="">Name</label>
                        <p><b><?php echo $row['full_name'] ?></b></p>
                    </div>

                    <div class="form-group">
                        <label for="">Username</label>
                        <p><b><?php echo $row['username'] ?></b></p>
                    </div>
                    
                    <div class="form-group">
                        <label for="">E-mail</label>
                        <p><b><?php echo $row['email'] ?></b></p>
                    </div>
                    <div class="form-group">
                        <label for="">Password</label>
                        <p><b><?php echo $row['password'] ?></b></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
    </html>