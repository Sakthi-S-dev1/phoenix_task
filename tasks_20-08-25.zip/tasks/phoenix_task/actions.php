<?php
function log_action($conn, $user_id, $user_name, $action, $role) {
    $sql = "INSERT INTO actions_log_book (user_id, user_name, actions, action_time, user_role) 
            VALUES ('$user_id', '$user_name', '$action',NOW(), '$role')";
    
    if (!mysqli_query($conn, $sql)) {
        die("Log insert failed: " . mysqli_error($conn));
    }
}

?>
