$(document).ready(function () {
    console.log("brands.js loaded");
    // brand name validation
    $("#brandNameAdd").on("input", function () {
        validateBrandName($("#brandNameAdd"), $("#nameErrAdd"));
    });
        $("#brandNameUpdate").on("input", function () {
        validateBrandName($("#brandNameUpdate"), $("#nameErrUpdate"));
    });

    function validateBrandName($B_name, $B_nameErr) {
        let name = $B_name.val().trim();
        let namePattern = /^[A-Za-z -]+$/;
        let isValid = true;

        if (name === "") {
            $B_name.addClass("is-invalid");
            $B_nameErr.text("name is required");
            isValid = false;
        } else if (name.length < 4) {
            $B_name.addClass("is-invalid");
            $B_nameErr.text("Must be at least 4 characters");
            isValid = false;
        } else if (!namePattern.test(name)) {
            $B_name.addClass("is-invalid");
            $B_nameErr.text("Only letters, hyphen and spaces allowed");
            isValid = false;
        } else {
            $B_name.removeClass("is-invalid");
            $B_nameErr.text("");
        }
        return isValid;
    }
    $("#addForm").on("submit", function (e) {
        e.preventDefault();

        let nameOk = validateBrandName($("#brandNameAdd"), $("#nameErrAdd"));

        if (!nameOk) {
            $("#msg").html(`
            <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                Please clear the errors above and then proceed.
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
        `);
        } else {

            $.ajax({
                url: "brand_action.php"/* $(this).attr("action") */,
                type: "post"/* $(this).attr("method") */,
                data: $(this).serialize(),
                success: function (response) {
                    console.log(response);
                    if (response == "success") {
                        $("#msg").html(`
                    <div class='alert alert-success alert-dismissible fade show' role='alert'>
                        Added successfully.
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>
                `);
                        setTimeout(function () {
                            window.location.reload();
                        }, 2000);
                    }
                    else if (response == "existing") {
                        $("#msg").html(`
                    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                        already exsisting brand name not allowed.
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>
                `);
                    }
                    else {
                        alert("action failed");
                    }

                },
                error: function () {
                    $("#msg").html(`
                    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                     error occurred: ajax failed.
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>
                `);
                }
            });
        }
    });

    $("#updateForm").on("submit", function (e) {
        e.preventDefault();
        let nameOk = validateBrandName($("#brandNameUpdate"), $("#nameErrUpdate"));

        if (!nameOk) {
            e.preventDefault();
            $("#msg").html(`
            <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                please clear the errors above and then proceed.
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
        `);
        } else {
            $.ajax({
                url: "brand_action.php"/* $(this).attr("action") */,
                type: "post"/* $(this).attr("method") */,
                data: $(this).serialize(),
                success: function (response) {
                    console.log(response);

                    if (response == "success") {
                        $("#msg").html(`
                    <div class='alert alert-success alert-dismissible fade show' role='alert'>
                        updated successfully.
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>
                `);
                        setTimeout(function () {
                            window.location.reload();
                        }, 2000);
                    }
                    else if (response == "existing") {
                        $("#msg").html(`
                    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                        already exsisting brand name not allowed.
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>
                `);
                    }

                },
                error: function () {
                    $("#msg").html(`
                    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                     error occurred: ajax failed.
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>
                `);
                }
            });
        }
    });
});