$(document).ready(function () {
  $("#userName").on("input", function () {
    validateName();
  });

  $("#email").on("input", function () {
    validateEmail();
  });

  $("#phone").on("input", function () {
    validatePhoneNumber();
  });

  $("#password").on("input", function () {
    validatePass();
  });

  $("#role").on("change", function () {
    validateRole();
  });

  //name validation
  function validateName() {
    let name = $("#userName").val().trim();
    let namePattern = /^[A-Za-z\s]+$/;
    let isValid = true;
    if (name === "") {
      $("#userName").addClass("is-invalid");
      $("#nameErr").text("name is riquired");
      isValid = false;
    } else if (name.length < 6) {
      $("#userName").addClass("is-invalid");
      $("#nameErr").text("minimum 6 characters is riquired");
      isValid = false;
    } else if (!namePattern.test(name)) {
      $("#userName").addClass("is-invalid");
      $("#nameErr").text("only letters and spaces are allowed");
      isValid = false;
    } else {
      $("#userName").removeClass("is-invalid");
      $("#nameErr").text("");
    }
    return isValid;
  }
  //phone number validation
  function validatePhoneNumber() {
    let phone = $("#phone").val().trim();
    let phonePattern = /^[0-9]{10}$/;
    isValid = true;
    if (phone === "") {
      $("#phone").addClass("is-invalid");
      $("#phoneErr").text("phone number is required");
      isValid = false;
    } else if (!phonePattern.test(phone)) {
      $("#phone").addClass("is-invalid");
      $("#phoneErr").text(
        "phone number must be exactly 10 digits (numbers only)"
      );
      isValid = false;
    } else {
      $("#phone").removeClass("is-invalid");
      $("#phoneErr").text("");
    }
    return isValid;
  }
  //email validation
  function validateEmail() {
    let email = $("#email").val().trim();
    let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    isValid = true;
    if (email === "") {
      $("#email").addClass("is-invalid");
      $("#emailErr").text("email is required");
      isValid = false;
    } else if (!emailPattern.test(email)) {
      $("#email").addClass("is-invalid");
      $("#emailErr").text("please enter the valid email id");
      isValid = false;
    } else {
      $("#email").removeClass("is-invalid");
      $("#emailErr").text("");
    }
    return isValid;
  }
  //password walidation
  function validatePass() {
    let pass = $("#password").val().trim();
    let passPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/;
    let isValid = true;
    if (pass === "") {
      $("#password").addClass("is-invalid");
      $("#passErr").text("password is required");
      isValid = false;
    } else if (pass.length < 6) {
      $("#password").addClass("is-invalid");
      $("#passErr").text("password must be atleast 6 characters");
      isValid = false;
    } else if (!passPattern.test(pass)) {
      $("#password").addClass("is-invalid");
      $("#passErr").text(
        "Password must contain at least one letter and one number"
      );
      isValid = false;
    } else {
      $("#password").removeClass("is-invalid");
      $("#passErr").text("");
    }
    return isValid;
  }
  //role validation
  function validateRole() {
    let role = $("#role").val();
    isValid = true;
    if (role == "") {
      $("#role").addClass("is-invalid");
      $("#roleErr").text("please select the role");
      isValid = false;
    } else {
      $("#role").removeClass("is-invalid");
      $("#roleErr").text("");
    }
    return isValid;
  }
/* user add form */
  $("#addUserForm").submit(function (e) {
    e.preventDefault();

    // Check all validations before sending AJAX
    let nameOK = validateName();
    let phoneOk = validatePhoneNumber();
    let emailOK = validateEmail();
    let passOk = validatePass();
    let roleOk = validateRole();

    if (!nameOK || !phoneOk || !emailOK || !passOk || !roleOk) {
      $("#message").html(`
            <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                please clear the errors above and then proceed.
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
        `);
      return; // Stop submission if any field invalid
    }
    else {
      $.ajax({
        url: "add_user_insert.php",
        type: "POST",
        data: $(this).serialize(),
        success: function (response) {
          let msg = response;
          console.log(response);
          if (msg === "success") {
            $("#message").html(`
                                <div class='alert alert-success alert-dismissible fade show' role='alert'>
                                    User added successfully.
                                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                                </div>
                            `);
            $("#addUserForm")[0].reset();
          } else {
            $("#message").html(`
                  <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                    ${response}
                    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                  </div>
            `);
          }
        },

        error: function () {
          $("#message").html(`
                            <div class = "alert alert-danger alert-dismissible fade show" role = "alert" >
                            Something went wrong. 
                            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                        </div>
                        `);
        },
      });
    }

  });
/* user edit form */
    $("#UpdateUserForm").submit(function (e) {
    e.preventDefault();

    // Check all validations before sending AJAX
    let nameOK = validateName();
    let phoneOk = validatePhoneNumber();
    let emailOK = validateEmail();
    let passOk = validatePass();
    let roleOk = validateRole();

    if (!nameOK || !phoneOk || !emailOK || !passOk || !roleOk) {
      $("#message").html(`
            <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                please clear the errors above and then proceed.
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
        `);
      return; // Stop submission if any field invalid
    }
    else {
      $.ajax({
        url: "../users/users_operations.php",
        type: "POST",
        data: $(this).serialize(),
        success: function (response) {
          let msg = response;
          console.log(response);
          if (msg === "success") {
            $("#message").html(`
                                <div class='alert alert-success alert-dismissible fade show' role='alert'>
                                    User Updated successfully.
                                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                                </div>
                            `);
              setTimeout(function(){
                window.location.href="user_list.php";
              },2000);
            $("#UpdateUserForm")[0].reset();
          } else {
            $("#message").html(`
                  <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                    hohoh
                    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                  </div>
            `);
          }
        },

        error: function () {
          $("#message").html(`
                            <div class = "alert alert-danger alert-dismissible fade show" role = "alert" >
                            Something went wrong. 
                            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                        </div>
                        `);
        },
      });
    }

  });
  
});
