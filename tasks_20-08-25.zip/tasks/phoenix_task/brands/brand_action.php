<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require '../auth_session.php';
$user_name = $_SESSION['user_name'];
$role = $_SESSION['role'];

require '../db.php';
require "../actions.php";

/* this is the crud handling section using the ['action'] */
if ($_SERVER['REQUEST_METHOD'] === "POST" && isset($_POST['action']) && $role === "admin") {

    /* this is for the add action */
    if ($_POST['action'] === "add") {
        $brand = $_POST['brand'];

        if (!empty($brand)) {
            $check_sql = "SELECT * FROM brands";
            if ($r = mysqli_query($conn, $check_sql)) {
                while ($row = mysqli_fetch_assoc($r)) {
                    if ($row['brand_name'] == $brand) {
                        echo "existing";
                        exit;
                    }
                }
            }

            $sql = "INSERT INTO brands(brand_name,added_at) VALUES('$brand',NOW())";

            if (mysqli_query($conn, $sql)) {
                $action = "new brand added:$brand";
                log_action($conn, $_SESSION['user_id'], $user_name, $action, $role);
                echo "success";
            }
        }
    }

    /* this for update */
    if ($_POST['action'] === "update" && isset($_POST['update_id'])) {
        $id = $_POST['update_id'];
        $brand = $_POST['brand'];

        if (!empty($brand)) {
            $check_sql = "SELECT * FROM brands";
            if ($r = mysqli_query($conn, $check_sql)) {
                while ($row = mysqli_fetch_assoc($r)) {
                    if ($row['brand_name'] == $brand) {
                        echo "existing";
                        exit;
                    }
                }
            }

            $sql = "UPDATE brands SET brand_name = '$brand',updated_at=NOW() WHERE id='$id'";
            $result = mysqli_query($conn, $sql);
            if ($result) {
            
                $action = "brand updated: $brand";
                log_action($conn, $_SESSION['user_id'], $user_name, $action, $role);
                echo "success";
                
            } else {
                echo "Qerr";
                
            }
        }
    }
}
?>