<?php
require "../auth_session.php";
$user_name = $_SESSION['user_name'];
$role = $_SESSION['role'];
require "../db.php";
if(isset($_GET['id']) && is_numeric($_GET['id'])){
    $id = $_GET['id'];

    $sql = "DELETE FROM category WHERE id = '$id'";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("location: category.php");
    }
    echo "query isn't executed.";
}
echo "invalid id";
?>