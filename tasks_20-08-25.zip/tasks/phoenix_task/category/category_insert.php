<?php
require '../auth_session.php';
$user_name = $_SESSION['user_name'];
$role = $_SESSION['role'];

require '../db.php';

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $category = $_POST['category'];

    $sql = "INSERT INTO category(category_name,added_at) VALUES('$category', NOW())";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("location: category.php");
    }
}
?>