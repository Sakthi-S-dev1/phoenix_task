<?php
$conn = mysqli_connect("localhost","root","","phoenix_task");
if(!$conn){
    die("db not connected");
}
?>