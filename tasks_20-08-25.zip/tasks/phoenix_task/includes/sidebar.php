<?php
$prefix = '';
if (basename($_SERVER['PHP_SELF']) !== 'index.php') {
  $prefix = '../';
}

$user_name = $_SESSION['user_name'];
$role = $_SESSION['role'];
?>
<nav class="sidebar d-flex flex-column" id="sidebar">
  <div class="sidebar-logo">
    <img src="<?php echo $prefix; ?>assets/logo.png" alt="Logo" />
  </div>

  <ul class="flex-grow-1">
    <li><a href="<?php echo $prefix; ?>index.php"><i class="fas fa-home"></i><span> Dashboard </span></a></li>

    <?php #if ($role === 'admin') : ?>
      <li><a href="<?php echo $prefix; ?>users/user_list.php"><i class="fas fa-user-plus"> </i> <span>Users</span></a></li>
    <?php #endif; ?>

    <li>
      <a href="<?php echo $prefix; ?>warehouse/warehouse_list.php">
        <i class="fas fa-warehouse"></i><span>Warehouse</span>
      </a>
    </li>

    <li class="has-submenu">
      <a href="#" class="submenu-toggle">
        <i class="fas fa-sitemap"></i><span>Masters</span>
        <i class="fas fa-chevron-down arrow"></i>
      </a>
      <ul class="submenu">
        <li>
          <a href="<?php echo $prefix; ?>brands/brands.php">
            <i class="fas fa-tags"></i><span>Brands</span>
          </a>
        </li>
        <li>
          <a href="<?php echo $prefix; ?>category/category.php">
            <i class="fas fa-th-large"></i><span>Categories</span>
          </a>
        </li>

      </ul>
    </li>
  </ul>
</nav>