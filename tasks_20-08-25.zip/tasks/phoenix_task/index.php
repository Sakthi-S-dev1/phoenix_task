<?php 

require 'auth_session.php';
$user_name = $_SESSION['user_name'];
$role = $_SESSION['role'];
/* var_dump($_SESSION); // or print_r($_SESSION);
exit; */
/* echo "alert('".$role."')";
echo "alert('".$user_name."')"; */
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- font-awesome icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <!-- Select2 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

  <!-- jQuery (required by Select2) -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link rel="icon" href="./assets/favicon/android-chrome-192x192.png" type="image/x-icon" />

  <!-- Select2 JS -->
  <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

  <!-- bootstrap icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="assets2/styles.css" />
</head>

<body>

  <!-- Sidebar will be injected here -->
  <div class="toggle-btn" id="toggleBtn">
    <i class="fas fa-bars"></i>
  </div>

  <?php include "includes/sidebar.php"; ?>

  <!-- Main Content -->
  <div class="main-content" id="mainContent">
    <!-- Header -->
    <div id="mainHeader" class="header d-flex justify-content-between align-items-center px-4 py-2 bg-white border-bottom shadow-sm w-100">
      <h4 class="fw-bold mb-0">Dashboard</h4>

      <?php include "users/nav_profile.php"; ?>

      <!-- Notification Panel -->
      <div id="notificationPanel" class="position-fixed top-0 end-0 bg-white border shadow z-3 p-3" style="display: none; width: 300px; height: 100vh;">
        <div class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-2">
          <h5 class="mb-0">Notifications</h5>
          <button id="closeNotification" class="btn-close"></button>
        </div>
        <div class="notification-body px-3 py-2">
          <!-- Notification 1 -->
          <div class="mb-3 border-bottom pb-2">
            <h6 class="mb-1">New Laptop Order</h6>
            <small class="text-muted">2025-05-08 10:35 AM</small>
            <p class="mb-0">Order <strong>#ORD-1234</strong> by <strong>John Doe</strong> — <em>Dell Inspiron 15</em>.</p>
          </div>

          <!-- Notification 2 -->
          <div class="mb-3 border-bottom pb-2">
            <h6 class="mb-1">Low Stock Alert</h6>
            <small class="text-muted">2025-05-07 04:21 PM</small>
            <p class="mb-0"><strong>Asus VivoBook 14</strong> remaining: 2 units.</p>
          </div>

          <!-- Notification 3 -->
          <div class="mb-3 border-bottom pb-2">
            <h6 class="mb-1">Price Updated</h6>
            <small class="text-muted">2025-05-06 02:10 PM</small>
            <p class="mb-0"><strong>Lenovo ThinkPad E14</strong> now ₹58,000.</p>
          </div>

          <!-- Notification 4 -->
          <div class="mb-3 border-bottom pb-2">
            <h6 class="mb-1">Product Returned</h6>
            <small class="text-muted">2025-05-05 11:30 AM</small>
            <p class="mb-0"><strong>Dell Latitude 3420</strong> returned for screen issue.</p>
          </div>

          <!-- Notification 5 -->
          <div>
            <h6 class="mb-1">New Product Added</h6>
            <small class="text-muted">2025-05-04 09:15 AM</small>
            <p class="mb-0"><strong>Asus TUF Gaming A15</strong> — 15 units in stock.</p>
          </div>
        </div>

      </div>
    </div>



    <!-- Push content below fixed header -->
    <div style="padding-top: 30px;">

      <div class="dropdown-area row g-3 mb-4">
        <div class="col-md-6">
          <select class="form-select select2 border border-warning" id="categorySelect">
            <option value="">Select Category</option>
            <option value="Laptops">Laptops</option>
            <option value="Computers">Computers</option>
            <option value="Mobiles">Mobiles</option>
          </select>
        </div>
        <div class="col-md-6">
          <select class="form-select select2 border border-warning" id="brandSelect">
            <option value="">Select Brand</option>
            <option value="Hp">Hp</option>
            <option value="Asus">Asus</option>
            <option value="Lenova">Lenova</option>
          </select>
        </div>
      </div>

      <div class="row g-4 mb-4">
        <div class="col-md-3">
          <div class="stat-card gradient-1">
            <div class="icon"><i class="bi bi-list"></i></div>
            <h6>Category</h6>
            <h2>02</h2>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stat-card gradient-2">
            <div class="icon"><i class="bi bi-box"></i></div>
            <h6>Stock</h6>
            <h2>1550</h2>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stat-card gradient-3">
            <div class="icon"><i class="bi bi-tag"></i></div>
            <h6>Brand</h6>
            <h2>04</h2>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stat-card gradient-4">
            <div class="icon"><i class="bi bi-people"></i></div>
            <h6>Customer</h6>
            <h2>09</h2>
          </div>
        </div>
      </div>


      <div class="row g-4">
        <div class="col-md-6">
          <div class="card shadow-sm rounded-4">
            <div class="card-body">
              <h6 class="fw-bold mb-3">Brand</h6>
              <select class="form-select mb-3">
                <option>Select a brand</option>
                <option>HP</option>
                <option>DELL</option>
                <option>LENOVA</option>
              </select>
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>Brand</th>
                    <th>Model</th>
                    <th>Stock</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>VIVO</td>
                    <td>MX-1234</td>
                    <td>5</td>
                  </tr>
                  <tr>
                    <td>VIVO</td>
                    <td>MX-2345</td>
                    <td>5</td>
                  </tr>
                  <tr>
                    <td>VIVO</td>
                    <td>—</td>
                    <td>5</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card shadow-sm rounded-4">
            <div class="card-body">
              <h6 class="fw-bold mb-3">Brand</h6>
              <select class="form-select mb-3">
                <option>Select a brand</option>
                <option>VIVO BOOK</option>
                <option>ASUS</option>
                <option>SAMSUNG</option>
              </select>
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>Brand</th>
                    <th>Model</th>
                    <th>Stock</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>VIVO</td>
                    <td>MX-1234</td>
                    <td>5</td>
                  </tr>
                  <tr>
                    <td>VIVO</td>
                    <td>MX-2345</td>
                    <td>5</td>
                  </tr>
                  <tr>
                    <td>VIVO</td>
                    <td>—</td>
                    <td>5</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <div class="container my-4">
        <div class="row g-4">
          <!-- Warehouse 1 -->
          <div class="col-md-4">
            <div class="card shadow-sm rounded-4">
              <div class="card-body">
                <i class="fas fa-warehouse"></i> WH 1
              </div>
              <div class="warehouse-body">
                <table class="table">
                  <thead class="custom-thead text-center">
                    <tr>
                      <th>BRAND</th>
                      <th>MODEL</th>
                      <th>STOCK</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>HP</td>
                      <td>Pavilion 15</td>
                      <td>45</td>
                    </tr>
                    <tr>
                      <td>Dell</td>
                      <td>Inspiron 3501</td>
                      <td>30</td>
                    </tr>
                    <tr>
                      <td>Lenovo</td>
                      <td>IdeaPad Slim 3</td>
                      <td>20</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <!-- Warehouse 2 -->
          <div class="col-md-4">
            <div class="card shadow-sm rounded-4">
              <div class="card-body">
                <i class="fas fa-warehouse"></i> WH 2
              </div>
              <div class="warehouse-body">
                <table class="table">
                  <thead class="custom-thead text-center">
                    <tr>
                      <th>BRAND</th>
                      <th>MODEL</th>
                      <th>STOCK</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>ASUS</td>
                      <td>ROG Zephyrus </td>
                      <td>15</td>
                    </tr>
                    <tr>
                      <td>Acer</td>
                      <td>Nitro 5</td>
                      <td>25</td>
                    </tr>
                    <tr>
                      <td>MSI</td>
                      <td>GF63 Thin</td>
                      <td>18</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <!-- Warehouse 3 -->
          <div class="col-md-4">
            <div class="card shadow-sm rounded-4">
              <div class="card-body">
                <i class="fas fa-warehouse"></i> WH 3
              </div>
              <div class="warehouse-body">
                <table class="table">
                  <thead class="custom-thead text-center">
                    <tr>
                      <th>BRAND</th>
                      <th>MODEL</th>
                      <th>STOCK</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Apple</td>
                      <td>MacBook Air M2</td>
                      <td>12</td>
                    </tr>
                    <tr>
                      <td>Apple</td>
                      <td>MacBook Pro 14"</td>
                      <td>10</td>
                    </tr>
                    <tr>
                      <td>Microsoft</td>
                      <td>Surface Laptop 5</td>
                      <td>8</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>


      </main>



      </main>

      <!-- Sidebar loading script -->
      <script src="assets2/script.js"></script>
      <script>
        document.addEventListener('DOMContentLoaded', () => {
          const bellIcon = document.getElementById('notificationBell');
          const notificationPanel = document.getElementById('notificationPanel');
          const closeBtn = document.getElementById('closeNotification');

          if (bellIcon && notificationPanel && closeBtn) {
            bellIcon.addEventListener('click', (e) => {
              e.stopPropagation();
              notificationPanel.classList.toggle('open');
            });

            closeBtn.addEventListener('click', () => {
              notificationPanel.classList.remove('open');
            });

            document.addEventListener('click', (e) => {
              if (!notificationPanel.contains(e.target) && e.target !== bellIcon) {
                notificationPanel.classList.remove('open');
              }
            });
          }
        });
      </script>
      <script>
        $(document).ready(function() {
          $('#categorySelect').select2({
            placeholder: "Select or type category",
            tags: true,
            width: '100%'
          });
        });

        $(document).ready(function() {
          $('#brandSelect').select2({
            placeholder: "Select or type brand",
            tags: true,
            width: '100%'
          });
        });
      </script>




      <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
      <!-- Bootstrap Bundle JS (includes Popper.js) -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

      <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
</body>

</html>