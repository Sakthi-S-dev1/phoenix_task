<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>LOG-in</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Bootstrap JS Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- bootstrap icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css" />
</head>

<body class="d-flex justify-content-center align-items-center min-vh-100 bg-light">

    <div class="container px-3">
        <div class="card shadow-sm rounded-4 m-auto" style="width:400px;">
            <div class="auth-logo" style="text-align: center; margin-bottom: 15px;">
                <img src="assets/logo.png" alt="Logo" style="height: 100px;" width="250px" />
            </div>

            <div class="card-body">
                <form class="row" id="loginForm" method="POST" action="login_check.php">
                    <h2 class="text-center">LOGIN</h2>
                    <div class="col">
                        <label for="email" class="form-label">E-Mail</label>
                        <input
                            type="text"
                            class="form-control mb-3"
                            id="email"
                            name="email"
                            placeholder="Enter email"
                            required />

                        <label for="password" class="form-label">PASSWORD</label>
                        <input
                            type="text"
                            class="form-control mb-3"
                            id="password"
                            name="password"
                            placeholder="Enter Password"
                            required />

                        <div class="text-center">
                            <button type="submit" class="btn btn-success btn-lg" style="background-color: #f47820 !important; border:none;">Login</button>
                        </div>
                    </div>
                </form>
            </div>
            <div id="loginMessage"></div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $("#loginForm").submit(function(e) {
            e.preventDefault();

            $.ajax({
                url: "login_check.php",
                type: "POST",
                data: $(this).serialize(),
                success: function(response) {
                    if (response.trim() === "success") {
                        window.location.href = "index.php";
                    } else {
                        $("#loginMessage").html(`
                            <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                                ${response}
                                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                            </div>
                        `);
                    }
                },
                error: function() {
                    $("#loginMessage").html(`
                        <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                            Something went wrong.
                            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                        </div>
                    `);
                }
            });
        });
    </script>
</body>

</html>