<?php
require "db.php";
session_start();

$email = trim($_POST['email']);
$password = trim($_POST['password']);

if ($email === "" || $password === "") {
    echo "All fields are required";
    exit;
}

$sql = "SELECT * FROM users WHERE email = '$email'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) === 1) {
    $row = mysqli_fetch_assoc($result);

    if ($password === $row['password']) {

        $user_id = $_SESSION['user_id'] = $row['id'];
        $user_name = $_SESSION['user_name'] = $row['username'];
        $user_role = $_SESSION['role'] = $row['role'];

        $sql = "INSERT INTO users_log_book(user_id, user_name, user_role, login_at) VALUES('$user_id','$user_name','$user_role', NOW())";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            echo "success";
        }
    } else {
        echo "Incorrect password";
    }
} else {
    echo "Email not found";
}
