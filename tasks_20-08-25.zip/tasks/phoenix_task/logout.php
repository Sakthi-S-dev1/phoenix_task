<?php
session_start();
require "./db.php";
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $sql = "UPDATE users_log_book set logout_at = NOW() WHERE user_id = '$user_id' ";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        session_unset();
        session_destroy();
        header("Location: login.php");
        exit;
    }
}
