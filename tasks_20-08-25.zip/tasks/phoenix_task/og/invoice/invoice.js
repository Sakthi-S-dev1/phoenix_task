window.addEventListener("DOMContentLoaded", () => {
  let products = [];

  // Get button elements
  const addProductBtn = document.getElementById('invoiceAddProductBtn');
  const generateInvoiceBtn = document.getElementById('invoiceGenerateBtn');

  // Attach event listeners 
  addProductBtn.addEventListener('click', addProduct);
  generateInvoiceBtn.addEventListener('click', generateInvoice);

  // === Add Product Function ===
  function addProduct() {
    const name = document.getElementById('invoiceProductName').value.trim();
    const model = document.getElementById('invoiceProductModel').value.trim();
    const qty = parseInt(document.getElementById('invoiceProductQty').value);
    const price = parseFloat(document.getElementById('invoiceProductPrice').value);

    if (!name || !model || isNaN(qty) || qty <= 0 || isNaN(price) || price < 0) {
      alert('❌ Please enter valid product details.');
      return;
    }

    const productFullName = `${name} - ${model}`;
    products.push({ name: productFullName, qty, price, total: qty * price });

    updateProductTable();
    clearProductFields();
    updateTotals();
  }

  // === Update Product Table ===
  function updateProductTable() {
    const tbody = document.querySelector('#invoiceProductTable tbody');
    tbody.innerHTML = '';

    products.forEach((product, index) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${index + 1}</td>
        <td>${product.name}</td>
        <td>${product.qty}</td>
        <td>₹${product.price.toFixed(2)}</td>
        <td>₹${product.total.toFixed(2)}</td>
       <td>
  <button class="btn btn-sm btn-danger" onclick="removeProduct(${index})">
    <i class="fas fa-trash-alt"></i>
  </button>
</td>

      `;
      tbody.appendChild(row);
    });
  }

  // === Remove Product Globally Accessible ===
  window.removeProduct = function(index) {
    products.splice(index, 1);
    updateProductTable();
    updateTotals();
  };

  // === Clear Fields After Adding Product ===
  function clearProductFields() {
    document.getElementById('invoiceProductName').value = '';
    document.getElementById('invoiceProductModel').value = '';
    document.getElementById('invoiceProductQty').value = '';
    document.getElementById('invoiceProductPrice').value = '';
  }

  // === Update Totals ===
  function updateTotals() {
    const subtotal = products.reduce((sum, p) => sum + p.total, 0);
    const tax = +(subtotal * 0.18).toFixed(2);
    const grandTotal = +(subtotal + tax).toFixed(2);

    document.getElementById('invoiceSubtotal').textContent = subtotal.toFixed(2);
    document.getElementById('invoiceTax').textContent = tax.toFixed(2);
    document.getElementById('invoiceGrandTotal').textContent = grandTotal.toFixed(2);
  }

  // === Generate Invoice Function ===
  function generateInvoice() {
    const customer = document.getElementById("invoiceCustomerName").value;
    const invoiceNumber = document.getElementById("invoiceNumber").value;
    const date = document.getElementById("invoiceDate").value;
    const mobile = document.getElementById("invoiceMobile").value;
    const address1 = document.getElementById("invoiceAddress1").value;
    const address2 = document.getElementById("invoiceAddress2").value;
    const state = document.getElementById("invoiceState").value;
    const city = document.getElementById("invoiceCity").value;
    const pincode = document.getElementById("invoicePincode").value;

    if (!customer || !invoiceNumber || !date || !mobile || !address1 || !state || !city || !pincode || products.length === 0) {
      alert("❌ Please fill all required fields and add at least one product.");
      return;
    }

    const subtotal = products.reduce((sum, p) => sum + p.total, 0);
    const tax = +(subtotal * 0.18).toFixed(2);
    const grandTotal = +(subtotal + tax).toFixed(2);

    const invoice = {
      invoiceNumber,
      date,
      customer,
      mobile,
      address1,
      address2,
      state,
      city,
      pincode,
      products,
      subtotal,
      tax,
      grandTotal
    };

    let allInvoices = JSON.parse(localStorage.getItem("invoices")) || [];
    allInvoices.push(invoice);
    localStorage.setItem("invoices", JSON.stringify(allInvoices));

    alert("✅ Invoice saved successfully!");
    window.location.href = "invoice-list.html";
  }

  // === Load Invoice List if on invoice-list.html ===
  const invoiceTable = document.querySelector("#invoiceTable tbody");
  if (invoiceTable) {
    const savedInvoices = JSON.parse(localStorage.getItem("invoices")) || [];

    savedInvoices.forEach((invoice, index) => {
      const tr = document.createElement("tr");

      tr.innerHTML = `
        <td>${index + 1}</td>
        <td>${invoice.invoiceNumber}</td>
        <td>${invoice.customer}</td>
        <td>${invoice.mobile}</td>
        <td>${invoice.city}, ${invoice.state}</td>
        <td>${invoice.date}</td>
        <td>${invoice.products.map(p => `${p.name} (x${p.qty})`).join(", ")}</td>
        <td>₹${invoice.grandTotal.toFixed(2)}</td>
      `;

      invoiceTable.appendChild(tr);
    });
  }
});
