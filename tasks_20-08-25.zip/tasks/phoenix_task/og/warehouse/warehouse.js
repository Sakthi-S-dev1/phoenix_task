 function addField() {
    const container = document.getElementById('warehouseStockFields');
    const existingEntry = document.querySelector('.warehouse-entry');
    const newEntry = existingEntry.cloneNode(true);

    // Clear the inputs in the cloned node
    newEntry.querySelectorAll('input').forEach(input => input.value = '');

    // Re-attach event listener to remove button
    const removeBtn = newEntry.querySelector('.btn-danger');
    removeBtn.onclick = function () {
      this.closest('.warehouse-entry').remove();
    };

    container.appendChild(newEntry);
  }