<?php
require '../auth_session.php';
$user_name = $_SESSION['user_name'];
$role = $_SESSION['role'];

require "../db.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Add user</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Bootstrap JS Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- bootstrap icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets2/styles.css" />
</head>

<body>
    <!-- Sidebar Toggle Button -->
    <div class="toggle-btn" id="toggleBtn">
        <i class="fas fa-bars"></i>
    </div>
    <?php include_once "../includes/sidebar.php"; ?>
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <!-- Header -->
        <div id="mainHeader" class="header d-flex justify-content-between align-items-center px-4 py-2 bg-white border-bottom shadow-sm w-100">
            <h4 class="fw-bold mb-0">Add Users</h4>

            <?php include_once "../users/nav_profile.php"; ?>

            <!-- Notification Panel -->
            <div id="notificationPanel" class="position-fixed top-0 end-0 bg-white border shadow z-3 p-3" style="display: none; width: 300px; height: 100vh;">
                <div class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-2">
                    <h5 class="mb-0">Notifications</h5>
                    <button id="closeNotification" class="btn-close"></button>
                </div>
                <div class="notification-body px-3 py-2"></div>
            </div>
        </div>


        <!-- Push content below fixed header -->
        <div style="padding-top: 30px;"></div>

        <div class="container-fluid px-3">
            <div class="card shadow-sm rounded-4 mt-4">
                <div class="card-body">

                    <form class="row g-4" id="addUserForm" method="POST" action="">
                        <!-- hidden input -->
                         <input type="hidden" name="action" value="add">
                        <div class="col-md-6">
                            <label for="userName" class="form-label">
                                USER NAME <span class="text-danger">*</span>
                            </label>
                            <input
                                type="text"
                                class="form-control"
                                id="userName"
                                name="username"
                                placeholder="Enter Name" />
                            <div id="nameErr" class="text-start invalid-feedback"></div>
                        </div>

                        <div class="col-md-6">
                            <label for="phone" class="form-label">
                                PHONE <span class="text-danger">*</span>
                            </label>
                            <input
                                type="tel"
                                class="form-control"
                                id="phone"
                                name="phone"
                                placeholder="Enter Phone Number" />
                            <div id="phoneErr" class="text-start invalid-feedback"></div>
                        </div>

                        <div class="col-md-6">
                            <label for="email" class="form-label">
                                EMAIL <span class="text-danger">*</span>
                            </label>
                            <input
                                type="email"
                                class="form-control"
                                id="email"
                                name="email"
                                placeholder="Enter Email Address" />
                            <div id="emailErr" class="text-start invalid-feedback"></div>
                        </div>

                        <div class="col-md-6">
                            <label for="password" class="form-label">
                                PASSWORD <span class="text-danger">*</span>
                            </label>
                            <input
                                type="text"
                                class="form-control"
                                id="password"
                                name="password"
                                placeholder="Enter Password" />
                            <div id="passErr" class="text-start invalid-feedback"></div>
                        </div>

                        <div class="col-md-6">
                            <label for="address" class="form-label">ADDRESS</label>
                            <input
                                type="text"
                                class="form-control"
                                id="address"
                                name="address"
                                placeholder="Enter Address" />
                        </div>

                        <div class="col-md-6">
                            <label for="state" class="form-label">STATE</label>
                            <select class="form-select" id="state" name="state">
                                <option selected>Select State</option>
                                <option value="tamilnadu">TAMILNADU</option>
                                <option value="kerala">KERALA</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="city" class="form-label">CITY</label>
                            <input
                                type="text"
                                class="form-control"
                                id="city"
                                name="city"
                                placeholder="Enter City" />
                        </div>

                        <div class="col-md-6">
                            <label for="pincode" class="form-label">PINCODE</label>
                            <input
                                type="text"
                                class="form-control"
                                id="pincode"
                                name="pincode"
                                placeholder="Enter Pincode" />
                        </div>

                        <div class="col-md-6">
                            <label for="role" class="form-label">
                                SELECT ROLE <span class="text-danger">*</span>
                            </label>
                            <select class="form-select" name="role" id="role">
                                <option value="">--Select Role--</option>
                                <option value="user">USER</option>
                                <option value="admin">ADMIN</option>
                            </select>
                            <div id="roleErr" class="text-start invalid-feedback"></div>
                        </div>

                        <div class="col-12">
                            <!-- Success Button -->
                            <button type="submit" class="btn btn-success btn-lg">Save</button>
                        </div>

                        <div id="message" class="mt-3"></div>

                    </form>
                </div>
            </div>
        </div>

        <script src="../assets2/script.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="../assets2/users.js"></script>
</body>

</html>