<?php
require '../auth_session.php';
$user_name = $_SESSION['user_name'];
$role = $_SESSION['role'];

require "../db.php";
/* adding new user */
if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST['action'] == "add") {
    $username = trim($_POST['username']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);
    $password = trim($_POST['password']);
    $state = trim($_POST['state']);
    $city = trim($_POST['city']);
    $pincode = trim($_POST['pincode']);
    $role = trim($_POST['role']);

    if (empty($username) || empty($phone) || empty($email)) {
        echo "Please fill all required fields.";
        exit;
    }

    $sql = "INSERT INTO users (username, phone, email,password, address, state, city, pincode,role)
            VALUES ('$username','$phone','$email','$password','$address','$state','$city','$pincode','$role')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "success";
    } else {
        echo "Failed to add user.";
    }
}
if($_POST['action'] == "update" && isset($_POST['user_id'])){
    $id=$_POST['user_id'];
    $username = trim($_POST['username']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);
    $password = trim($_POST['password']);
    $state = trim($_POST['state']);
    $city = trim($_POST['city']);
    $pincode = trim($_POST['pincode']);
    $role = trim($_POST['role']);

    if (empty($username) || empty($phone) || empty($email)) {
        echo "Please fill all required fields.";
        exit;
    }

    $sql = "UPDATE users SET 
    username='$username',phone='$phone',email='$email',password='$password',address='$address',state='$state', city='$city', pincode='$pincode',role='$role' 
    WHERE id='$id'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "success";
    } else {
        echo "Failed to add user.";
    }

}

?>
