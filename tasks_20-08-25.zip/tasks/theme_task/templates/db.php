<?php
    $conn = mysqli_connect("localhost","root","","df"); 
if(!$conn){ 
    die("connection failed". mysqli_connect_error()); 
}
?>