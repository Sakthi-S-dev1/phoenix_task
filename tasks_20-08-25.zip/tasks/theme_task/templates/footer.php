      <div class="row mt-2 text-center">
          <div class="col-md-12">
              <span class="footer-text">2019 © stacks</span>
          </div>
      </div>