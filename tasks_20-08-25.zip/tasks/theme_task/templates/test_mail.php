
<?php
$to = "minemusiq001@gmail.com"; // change this to your own email for testing
$subject = "Test Mail from Localhost";
$message = "This is a test email using XAMPP and Gmail SMTP.";
$headers = "From: sakthi.ctrlnxt@gmail.com";

if (mail($to, $subject, $message, $headers)) {
    echo "✔️ Email sent successfully.";
} else {
    echo "❌ Failed to send email.";
}
?>
