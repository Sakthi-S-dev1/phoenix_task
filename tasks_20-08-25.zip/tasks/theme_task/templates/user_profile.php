<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from polygons.space/connect/theme/templates/admin1/profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 26 Jul 2025 08:05:51 GMT -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Responsive Admin Dashboard Template">
        <meta name="keywords" content="admin,dashboard">
        <meta name="author" content="stacks">
        <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        
        <!-- Title -->
        <title>Connect - Responsive Admin Dashboard Template</title>

        <!-- Styles -->
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,900&amp;display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700&amp;display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp" rel="stylesheet">
        <link href="../assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="../assets/plugins/font-awesome/css/all.min.css" rel="stylesheet">

      
        <!-- Theme Styles -->
        <link href="../assets/css/connect.min.css" rel="stylesheet">
        <link href="../assets/css/dark_theme.css" rel="stylesheet">
        <link href="../assets/css/custom.css" rel="stylesheet">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="app-profile">
        
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="connect-container align-content-stretch d-flex flex-wrap">
            <div class="page-sidebar">
                <?php
                    include "user_sidebar.php";
                ?>
            </div>
            <div class="page-container">
                <div class="page-header">
                    <?php
                        include "user_navbar.php";
                    ?>
                </div>
                <div class="page-content">
                    <div class="main-wrapper">
                        <div class="profile-header">
                            <div class="row">
                                <div class="col">
                                    <div class="profile-img">
                                        <img src="../assets/images/avatars/profile-image-1.png">
                                    </div>
                                    <div class="profile-name">
                                        <h3>User Name</h3>
                                        <span>Member of Envato</span>
                                    </div>
                                    <div class="profile-menu">
                                        <ul>
                                            <li>
                                                <a href="#">Feed</a>
                                            </li>
                                            <li>
                                                <a href="#">About</a>
                                            </li>
                                            <li>
                                                <a href="#">Friends</a>
                                            </li>
                                            <li>
                                                <a href="#">Photos</a>
                                            </li>
                                            <li>
                                                <a href="#">Videos</a>
                                            </li>
                                            <li>
                                                <a href="#">Music</a>
                                            </li>
                                        </ul>
                                        <div class="profile-status">
                                            <i class="active-now"></i> Active now
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="profile-content">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="post">
                                                <div class="post-header">
                                                    <img src="../assets/images/avatars/profile-image-3.jpg">
                                                    <div class="post-info">
                                                        <span class="post-author">Riley Beach</span><br>
                                                        <span class="post-date">3hrs</span>
                                                    </div>
                                                    <div class="post-header-actions">
                                                        <a href="#"><i class="fas fa-ellipsis-h"></i></a>
                                                    </div>
                                                </div>
                                                <div class="post-body">
                                                    <p>Proin eu fringilla dui. Pellentesque mattis lobortis mauris eu tincidunt. Maecenas hendrerit faucibus dolor, in commodo lectus mattis ac.</p>
                                                    <img src="../assets/images/post-1.jpg" class="post-image" alt="">
                                                </div>
                                                <div class="post-actions">
                                                    <ul class="list-unstyled">
                                                        <li>
                                                            <a href="#" class="like-btn"><i class="far fa-heart"></i>Like</a>
                                                        </li>
                                                        <li>
                                                            <a href="#"><i class="far fa-comment"></i>Comment</a>
                                                        </li>
                                                        <li>
                                                            <a href="#"><i class="fas fa-share"></i>Share</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="post-comments">
                                                    <div class="post-comm">
                                                        <img src="../assets/images/avatars/profile-image-2.png" class="comment-img">
                                                        <div class="comment-container">
                                                            <span class="comment-author">
                                                                Sonny Rosas
                                                                <small class="comment-date">5min</small>
                                                            </span>
                                                        </div>
                                                        <span class="comment-text">
                                                            Mauris ultrices convallis massa, nec facilisis enim interdum ac.
                                                        </span>
                                                    </div>
                                                    <div class="post-comm">
                                                        <img src="../assets/images/avatars/profile-image.png" class="comment-img">
                                                        <div class="comment-container">
                                                            <span class="comment-author">
                                                                Jacob Lee
                                                                <small class="comment-date">27min</small>
                                                            </span>
                                                        </div>
                                                        <span class="comment-text">
                                                            Cras tincidunt quam nisl, vitae aliquet enim pharetra at. Nunc varius bibendum turpis, vitae ultrices tortor facilisis ac.
                                                        </span>
                                                    </div>
                                                    <div class="new-comment">
                                                        <form action="javascript: void(0)">
                                                            <div class="input-group">
                                                                <input type="text" name="comment" class="form-control search-input" placeholder="Type something...">
                                                                <div class="input-group-append">
                                                                    <button class="btn btn-secondary" type="button" id="button-addon1">Comment</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="post">
                                                <div class="post-header">
                                                    <img src="../assets/images/avatars/profile-image.png">
                                                    <div class="post-info">
                                                        <span class="post-author">Haydon Kenny</span><br>
                                                        <span class="post-date">7hrs</span>
                                                    </div>
                                                    <div class="post-header-actions">
                                                        <a href="#"><i class="fas fa-ellipsis-h"></i></a>
                                                    </div>
                                                </div>
                                                <div class="post-body">
                                                    <p>Praesent purus purus, varius ac mauris quis, scelerisque ornare massa. Nam volutpat lacinia lectus, vitae mattis nisl. Mauris ultrices convallis massa, nec facilisis enim interdum ac. Suspendisse hendrerit risus nec nisi dictum efficitur. Pellentesque aliquet in justo id lobortis.</p>
                                                </div>
                                                <div class="post-actions">
                                                    <ul class="list-unstyled">
                                                        <li>
                                                            <a href="#" class="like-btn"><i class="far fa-heart"></i>Like</a>
                                                        </li>
                                                        <li>
                                                            <a href="#"><i class="far fa-comment"></i>Comment</a>
                                                        </li>
                                                        <li>
                                                            <a href="#"><i class="fas fa-share"></i>Share</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="post-comments">
                                                    <div class="post-comm">
                                                        <img src="../assets/images/avatars/profile-image-2.png" class="comment-img">
                                                        <div class="comment-container">
                                                            <span class="comment-author">
                                                                Riley Beach
                                                                <small class="comment-date">1hr</small>
                                                            </span>
                                                        </div>
                                                        <span class="comment-text">
                                                            Fusce mattis fermentum quam non porta...
                                                        </span>
                                                    </div>
                                                    <div class="new-comment">
                                                        <form action="javascript: void(0)">
                                                            <div class="input-group">
                                                                <input type="text" name="comment" class="form-control search-input" placeholder="Type something...">
                                                                <div class="input-group-append">
                                                                    <button class="btn btn-secondary" type="button" id="button-addon1">Comment</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">About</h5>
                                            <p>Quisque vel tellus sit amet quam efficitur sagittis. Fusce aliquam pulvinar suscipit.</p>
                                            <ul class="list-unstyled profile-about-list">
                                                <li><i class="material-icons">school</i><span>Studied Mechanical Engineering at <a href="#">Carnegie Mellon University</a></span></li>
                                                <li><i class="material-icons">work</i><span>Former manager at <a href="#">Stacks</a></span></li>
                                                <li><i class="material-icons">my_location</i><span>From <a href="#">Boston, Massachusetts</a></span></li>
                                                <li><i class="material-icons">rss_feed</i><span>Followed by 716 people</span></li>
                                                <li>
                                                    <button class="btn btn-block btn-primary m-t-lg">Follow</button>
                                                    <button class="btn btn-block btn-secondary m-t-lg">Message</button>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Contact Info</h5>
                                            <ul class="list-unstyled profile-about-list">
                                                <li><i class="material-icons">mail_outline</i><span>jay.morton@gmail.com</span></li>
                                                <li><i class="material-icons">home</i><span>Lives in <a href="#">San Francisco, CA</a></span></li>
                                                <li><i class="material-icons">local_phone</i><span>+1 (678) 290 1680</span></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="page-footer">
                    <?php
                        include "footer.php";
                    ?>
                </div>
            </div>
        
        <!-- Javascripts -->
        <script src="../assets/plugins/jquery/jquery-3.4.1.min.js"></script>
        <script src="../assets/plugins/bootstrap/popper.min.js"></script>
        <script src="../assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="../assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
        <script src="../assets/js/connect.min.js"></script>
    </body>

<!-- Mirrored from polygons.space/connect/theme/templates/admin1/profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 26 Jul 2025 08:05:54 GMT -->
</html>